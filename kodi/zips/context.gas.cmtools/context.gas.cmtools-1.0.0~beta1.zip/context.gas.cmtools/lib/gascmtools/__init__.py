import xbmc
import xbmcaddon
from gasutils import WINDOW

ADDON = xbmcaddon.Addon(id='context.gas.cmtools')

try:
    DATA_DIR = xbmc.translatePath(ADDON.getAddonInfo('profile')).decode('utf-8')
except AttributeError:
    DATA_DIR = xbmc.translatePath(ADDON.getAddonInfo('profile'))

getString = ADDON.getLocalizedString
ADDON_ID = ADDON.getAddonInfo('id')


def setProperty(prop, var):
    WINDOW.setProperty("%s_%s" % (ADDON_ID, prop), str(var))


def getProperty(prop):
    return WINDOW.getProperty("%s_%s" % (ADDON_ID, prop))


def clearProperty(prop):
    return WINDOW.clearProperty("%s_%s" % (ADDON_ID, prop))




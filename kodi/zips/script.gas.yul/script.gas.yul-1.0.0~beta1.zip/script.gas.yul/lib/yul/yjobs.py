import time

import xbmcvfs
import json
import os
import threading
from gasutils import utils

from oauth2client import _helpers
from oauth2client import client
from . import getProperty, setProperty, DATA_DIR

class JStorage(client.Storage):

    def __init__(self, filename):
        super(JStorage, self).__init__(lock=threading.Lock())
        self._filename = filename

    def locked_get(self):

        job = None
        _helpers.validate_file(self._filename)
        try:
            f = open(self._filename, 'rb')
            content = f.read()
            f.close()
        except IOError:
            return job

        try:
            job = Job.from_json(content)
        except ValueError:
            pass

        return job

    def _create_file_if_needed(self):
        if not os.path.exists(self._filename):
            old_umask = os.umask(0o177)
            try:
                open(self._filename, 'a+b').close()
            finally:
                os.umask(old_umask)

    def locked_put(self, job):
        utils.createFileIfNeeded(self._filename)
        _helpers.validate_file(self._filename)
        f = open(self._filename, 'w')
        f.write(job.to_json())
        f.close()

    def locked_delete(self):
        os.unlink(self._filename)


class Job(object):

    def __init__(self, args, opt):
        self.opt = opt
        self.args = args
        self._request = None

    @classmethod
    def object_decoder(cls, obj):
        if 'opt' in obj and 'args' in obj:
            return cls(obj['args'], obj['opt'])

        return obj

    def to_json(self):
        return json.dumps({'args': self.args, 'opt': self.opt})

    def saveProgress(self):
        if self._request == None:
            return
        self.opt['resumable_uri'] = self._request.resumable_uri
        self.opt['resumable_progress'] = self._request.resumable_progress

    @classmethod
    def from_json(cls, json_str):
        return json.loads(json_str, object_hook=cls.object_decoder)

class YJobsLab(object):

    @staticmethod
    def getJobsFiles():
        return os.listdir(YJobsLab.getJobsDir())

    @staticmethod
    def deleteAllJobs():
        if getProperty('runned'):
            setProperty('stop', 'deleteall')
        utils.deleteAllFiles(YJobsLab.getJobsDir())

    @staticmethod
    def getJobsDir():
        jobsDir = os.path.join(DATA_DIR, 'yjobs', 'working')
        if not xbmcvfs.exists(jobsDir):
            if not utils.make_dirs(jobsDir):
                raise Exception('Failed to create directories in {filename}.'.format(filename=jobsDir.encode("utf-8")))
        return jobsDir

    def __init__(self):
        self.currentJob = None
        self.jobsDir = self.getJobsDir()

    def cleanJobs(self):
        self.currentJob = None
        self.storage = None

    def addJob(self, job):
        if self.currentJob == None:
            self.currentJob = job
        path = os.path.join (self.jobsDir, '%s.json' % time.time())
        self.storage = JStorage(path)
        self.storage.locked_put(job)

    def saveJobProgress(self):
        if self.currentJob != None:
            self.currentJob.saveProgress()
            self.storage.locked_put(self.currentJob)

    def peekJob(self):

        if self.currentJob:
            return self.currentJob

        list = os.listdir(self.jobsDir)
        if list:
            path = os.path.join(self.jobsDir, list[0])
            self.storage = JStorage(path)
            self.currentJob = self.storage.locked_get()
            return self.currentJob
        return None

    def deleteJob(self):
        try:
            self.storage.locked_delete()
        except:
            pass
        self.currentJob = None
        self.storage = None
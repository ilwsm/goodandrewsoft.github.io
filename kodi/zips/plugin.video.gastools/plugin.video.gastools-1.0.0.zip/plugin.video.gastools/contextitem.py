# coding=utf-8
import json
import sys

from lib.gascmtools import DIALOG
from lib.gascmtools.init import getString
from lib.gascmtools.logger import log

from ydl import other

sys.path.append(r'F:\Run\Lprogr\JetBrains\PyCharm\helpers\pydev')
import xbmc


def getPath(li):
    def getFilePath(method, name, id):
        params = {'properties': ['file']}
        data = {'jsonrpc': '2.0', 'params': params, 'id': '1'}
        data['method'] = method
        params[name + 'id'] = id
        deserialization = json.loads(xbmc.executeJSONRPC(json.dumps(data)))
        return deserialization['result'][name + 'details']['file']

    content = xbmc.getInfoLabel('Container.Content')
    # log("content:%s, vid:%s, aid:%s, path:%s" % (content, li.getVideoInfoTag().getDbId(), li.getMusicInfoTag().getDbId(), li.getPath()))
    # exit()

    path = li.getPath().decode('UTF-8')
    return path
    if (path[0] == '/' or path[1] == ':'):
        return path
    if content == "movies":
        path = getFilePath('VideoLibrary.GetMovieDetails', 'movie', li.getVideoInfoTag().getDbId())
    elif content == "episodes":
        path = getFilePath('VideoLibrary.GetEpisodeDetails', 'episode', li.getVideoInfoTag().getDbId())
    elif content == "songs":
        path = getFilePath('AudioLibrary.GetSongDetails', 'song', li.getMusicInfoTag().getDbId())
    else:
        path = None
    return path


if __name__ == '__main__':
    # content:movies, vid:27, aid:-1, path:videodb://recentlyaddedmovies/27
    # content:movies, vid:-1, aid:-1, path:plugin://plugin.video.hdrezka.tv/?mode=show&url=http%3a%2f%2fhdrezka.tv%2ffilms%2fdrama%2f32041-katcelmaher-1969.html
    # content:episodes, vid:690, aid:-1, path:videodb://tvshows/titles/39/-2/690?season=-2&tvshowid=39
    # content:files, vid:-1, aid:-1, path:D:\Sound\music\Alizee_-_Mademoiselle_Juliette.mp3
    # content:songs, vid:-1, aid:240, path:musicdb://songs/240.mp3

    li = sys.listitem
    filePath = getPath(li)
    if (filePath == None):
        exit()

    dialogsItems = [getString(30104), getString(30124)]
    ret = DIALOG.contextmenu(dialogsItems)
    if ret == 0:
        try:
            raise Exception
            # from yul import task
            # task.run(filePath)
        except:
            r = xbmc.getCondVisibility('System.hasAddon(script.gas.yul)')
            log("xbmc.getCondVisibility - System.hasAddon:" + str(r))

            r = xbmc.getCondVisibility('System.AddonIsEnabeled(script.gas.yul)')
            log("xbmc.getCondVisibility - System.AddonIsEnabeled:" + str(r))
            # xbmc.executebuiltin('EnableAddon(script.gas.yul)')

            import xbmc

            # xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "plugin.video.cbsn", "enabled": false }}')

            r = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Addons.GetAddonDetails", "id": 1, "params": {"addonid": "script.gas.yul", "properties": ["path", "installed", "enabled"] }}')
            r = json.loads(r)

            if 'error' in r:
                xbmc.executebuiltin('InstallAddon(script.gas.yul)')
                log(r['error']['code'])
            else:
                log(r)
    elif ret == 1:
        other(filePath)

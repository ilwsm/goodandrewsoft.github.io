# coding=utf-8

import os
import time

import xbmc, xbmcgui
from gascmtools import MONITOR, DIALOG, utils
from gascmtools.logger import log_debug, log_error, log
from googleapiclient.errors import HttpError

import playlists
from uploader import get_authenticated_service, initialize_upload
from yclient import YStorage
from yjobs import YJobsLab, Job
from ytools import getUploadPrivacy, getUploadCategrory, createAccount

from exceptions import DialogCancelledException, CurrentJobCancelException
import yul


def stopIfNeed():
    prop = yul.getProperty('stop')
    if MONITOR.abortRequested():
        exit()
    elif prop:
        if prop == 'deleteCurrent':
            raise CurrentJobCancelException
        exit()

class DialogCallback(object):

    def __init__(self, text):
        self.dialog = xbmcgui.DialogProgressBG()
        self.resume_len = 0
        self.startTime = None
        self.heading = text
        self.dialog.create(text, 'Uploading:')

    def start(self, text='', resumeLen=0):
        self.heading = text
        self.resume_len = resumeLen
        self.startTime = time.time()

    def update(self, total_size, byte_counter):
        stopIfNeed()
        if not self.startTime:
            self.start()

        now = time.time()
        speed = self.calc_speed(self.startTime, now, byte_counter - self.resume_len)
        eta = self.calc_eta(self.startTime, now, total_size - self.resume_len, byte_counter - self.resume_len)
        elapsed = now - self.startTime

        message = ['Uploading: ']
        if speed:
            message.append(utils.simpleSize(speed) + 's - ')
        if eta:
            message.append(' ETA: ' + utils.durationToShortText(eta) + '  |  ')

        message.append('(' + utils.simpleSize(byte_counter) + '/' + utils.simpleSize(total_size) + ')')
        self.dialog.update(100 * byte_counter / total_size, self.heading, ''.join(message))

    def close(self):
        self.dialog.close()

    def __del__(self):
        self.close()

    @staticmethod
    def calc_speed(start, now, bytes):
        dif = now - start
        if bytes == 0 or dif < 0.001:  # One millisecond
            return None
        return float(bytes) / dif

    @staticmethod
    def calc_eta(start, now, total, current):
        if total is None:
            return None
        if now is None:
            now = time.time()
        dif = now - start
        if current == 0 or dif < 0.001:  # One millisecond
            return None
        rate = float(current) / dif
        return int((float(total) - float(current)) / rate)


def run(filePath):
    lab = YJobsLab()
    storage = YStorage('')
    if filePath != None:
        job = createJob(filePath, storage)
        lab.addJob(job)
        if yul.getProperty('runned'):
            DIALOG.notification('Job added to queue', job.args['file'], xbmcgui.NOTIFICATION_INFO, 2000, False)
            exit()
    else:
        if yul.getProperty('runned'):
            exit()

    yul.setProperty('runned', True)
    pDialog = DialogCallback('Prepare upload')
    account_id = None
    youtube = None
    showSuccessNotify = False
    try:
        while (1):
            try:
                job = lab.peekJob()
                if not job:
                    log('not job')
                    break
                showSuccessNotify = True
                opt = job.opt
                args = job.args
                if account_id != opt['account_id']:
                    account_id = opt['account_id']
                    storage.switchAccount(account_id)
                    youtube = get_authenticated_service(storage)

                pDialog.start(os.path.basename(args['file']), job.opt['resumable_progress'])
                yid = initialize_upload(youtube, job, pDialog)
                playlist = args['yplaylist']
                if playlist:
                    playlists.add_video_to_playlist(youtube, yid, title=utils.to_utf8(playlist), privacy=args['privacyStatus'])
                stopIfNeed()
                lab.deleteJob()
                if job.opt['delete_file'] == 'true':
                    utils.deleteFile(job.args['file'])
                xbmc.executebuiltin("Container.Refresh")
            except CurrentJobCancelException:
                lab.deleteJob()
                yul.clearProperty('stop')
                showSuccessNotify = False
                continue
    except HttpError as e:
        log_error("An HTTP error %d occurred:\n%s" % (e.resp.status, e.content))
        raise
    except DialogCancelledException:
        pass
    except Exception:
        raise
    else:
        if showSuccessNotify:
            DIALOG.notification(yul.getString(30116), yul.getString(30120), xbmcgui.NOTIFICATION_INFO, 2000, False)
    finally:
        pDialog.close()
        prop = yul.getProperty('stop')

        if prop != 'deleteall':
            lab.saveJobProgress()
        clear()

def clear():
    yul.clearProperty('runned')
    yul.clearProperty('stop')


def createJob(filePath, storage):
    addon = yul.ADDON
    basename = os.path.basename(filePath)
    addon.setSetting('title', basename)
    addon.setSetting('description', '')

    if (addon.getSetting('show_upload') == 'true'):
        settingsFile = os.path.join(yul.DATA_DIR, 'settings.xml')
        try:
            stime = os.path.getmtime(settingsFile)
        except:
            stime = 0

        addon.openSettings()

        def isclose(f1, f2):
            return abs(f1 - f2) <= 0.0099999

        if isclose(os.path.getmtime(settingsFile), stime):
            log_debug('exited')
            exit()

    args = {}
    args['file'] = filePath
    args['title'] = addon.getSetting('title')
    args['description'] = addon.getSetting('description')
    args['keywords'] = addon.getSetting('keywords')
    args['category'] = getUploadCategrory()
    args['privacyStatus'] = getUploadPrivacy()
    args['yplaylist'] = addon.getSetting('yplaylist')
    options = {}
    try:
        accountName = addon.getSetting('account')
        if not accountName:
            accountName = createAccount()
        if not accountName:
            exit()
        else:
            addon.setSetting('account', accountName)
            options['account_id'] = storage.setName(accountName).getAccountId()
            options['delete_file'] = addon.getSetting('delete_file_after_upload')
            options['resumable_uri'] = None
            options['resumable_progress'] = 0
    except DialogCancelledException:
        exit()
    finally:
        addon.setSetting('title', '')
        addon.setSetting('description', '')

    job = Job(args, options)
    # log("created job:" + str(job))
    # exit()
    return job

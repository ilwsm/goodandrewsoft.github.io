# -*- coding: utf-8 -*-

class DialogCancelledException(Exception):
    pass

class AccountExistsException(Exception):
    pass

class CurrentJobCancelException(Exception):
    pass
import locale
import math
import os
import xbmc
import xbmcvfs
import xbmcgui

def secToTimeStr(seconds, sep=':'):
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    return '{0:02d}{3}{1:02d}{3}{2:02d}'.format(h, m, s, sep)


def deleteFile(path):
    try:
        os.remove(path)
    except:
        pass


def deleteAllFiles(folder):
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            # elif os.path.isdir(file_path): shutil.rmtree(file_path)
        except:
            pass


def getKodiVer():
    build = xbmc.getInfoLabel("System.BuildVersion")
    return int(build.split()[0][:2])


def getOS():
    os = None
    system = None
    platform = None

    try:
        system = platform.system()
    except:
        pass

    try:
        platform = platform.platform()
    except:
        pass

    if xbmc.getCondVisibility("system.platform.android"):
        os = "android"
    elif xbmc.getCondVisibility("system.platform.linux"):
        os = "linux"
    elif xbmc.getCondVisibility("system.platform.xbox"):
        os = "windows"
    elif xbmc.getCondVisibility("system.platform.windows"):
        os = "windows"
    elif system == "Darwin":
        os = "darwin"
        if "AppleTV" in platform:
            os = "ios"
        elif xbmc.getCondVisibility("system.platform.ios"):
            os = "ios"
    return os


def bold(value):
    return ''.join(['[B]', value, '[/B]'])


def make_dirs(path):
    if not path.endswith('/'):
        path = ''.join([path, '/'])
    path = xbmc.translatePath(path)
    if not xbmcvfs.exists(path):
        try:
            _ = xbmcvfs.mkdirs(path)
        except:
            pass
        if not xbmcvfs.exists(path):
            try:
                os.makedirs(path)
            except:
                pass
        return xbmcvfs.exists(path)

    return True


def make_dirs_if_not_exist(path):
    if not make_dirs(path):
        raise Exception('Failed to create directories in {filename}.'.format(filename=path.encode("utf-8")))


def durationToShortText(seconds):
    """
    Converts seconds to a short user friendly string
    Example: 143 -> 2m 23s
    """
    days = int(seconds / 86400)
    if days:
        return '%sd' % days
    left = seconds % 86400
    hours = int(left / 3600)
    if hours:
        return '%sh' % hours
    left = left % 3600
    mins = int(left / 60)
    if mins:
        return '%sm' % mins
    sec = int(left % 60)
    if sec:
        return '%ss' % sec
    return '0s'


SIZE_NAMES = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")


def simpleSize(size):
    """
    Converts bytes to a short user friendly string
    Example: 12345 -> 12.06 KB
    """
    if size > 0:
        i = int(math.floor(math.log(size, 1024)))
        p = math.pow(1024, i)
        s = round(size / p, 2)
        if s > 0:
            return '%s %s' % (s, SIZE_NAMES[i])
    return '0B'


def to_utf8(s):
    """Re-encode string from the default system encoding to UTF-8."""
    current = locale.getpreferredencoding()
    if hasattr(s, 'decode'):  # Python 3 workaround
        return (s.decode(current).encode("UTF-8") if s and current != "UTF-8" else s)
    elif isinstance(s, bytes):
        return bytes.decode(s)
    else:
        return s


def busyDialog(func):
    def inner(*args, **kwargs):
        try:
            xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
            return func(*args, **kwargs)
        finally:
            xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

    return inner


def createFileIfNeeded(filename):
    if not os.path.exists(filename):
        old_umask = os.umask(0o177)
        try:
            open(filename, 'a+b').close()
        finally:
            os.umask(old_umask)

def showInfoNotification(heading, message):
    xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_INFO, 2000, False)


def closeBusyDialog():
    xbmc.executebuiltin("Dialog.Close(busydialognocancel)")


def activateBusyDialog():
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")

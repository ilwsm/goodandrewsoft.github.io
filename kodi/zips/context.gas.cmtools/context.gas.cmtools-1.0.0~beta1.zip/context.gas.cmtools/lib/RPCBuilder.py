import xbmc
class RPCBuilder(object):

    def __init__(self, id, method=None):
        self.rpc = {"jsonrpc": "2.0", "method": method, "id": id}
        self.params = dict()
        self.jsonStr = None

    def withMethod(self, method):
        self.rpc['method'] = method
        return self

    def add(self, name, value):
        self.params[name] = value
        return self

    def build(self):
        import json
        self.rpc['params'] = self.params
        self.jsonStr = json.dumps(self.rpc)

    def toString(self):
        if (self.jsonStr == None):
            self.build()
        return self.jsonStr

    def execute(self):
        if (self.jsonStr == None):
            self.build()
        return xbmc.executeJSONRPC(self.jsonStr)
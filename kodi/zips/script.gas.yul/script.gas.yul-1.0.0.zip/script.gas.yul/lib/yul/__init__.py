import xbmcaddon, xbmc
from gascmtools import WINDOW

ADDON_ID = 'script.gas.yul'
ADDON = xbmcaddon.Addon(id=ADDON_ID)

key_sets = {
    '0': {
        'id': 'ODYxNTU2NzA4NDU0LWQ2ZGxtM2xoMDVpZGQ4bnBlazE4azZiZThiYTNvYzY4',
        'secret': 'U2JvVmhvRzlzMHJOYWZpeENTR0dLWEFU'
    },
    '1': {
        'id': 'Mjk0ODk5MDY0NDg4LWE4a2MxazFqZDAwa2FtcXJlMHZkMm5mdHVpaWZyZjZh',
        'secret': 'S1RrQktJTk41dmY0T3dqMU5ZeVhMemJl',
    },
    '2': {
        'id': 'MjExNTk2Mzk5NzctcjBqbnE1OW90MHY1NDNmb2RxY2ZubTJkZGl2MW1xNmU=', #zoom
        'secret': 'NjJRUWJBX2RHQ3JfRWFlZHZMOTRKYXRu',
    }
}

try:
    DATA_DIR = xbmc.translatePath(ADDON.getAddonInfo('profile')).decode('utf-8')
except AttributeError:
    DATA_DIR = xbmc.translatePath(ADDON.getAddonInfo('profile'))


getString = ADDON.getLocalizedString
ADDON_ID = ADDON.getAddonInfo('id')

def setProperty(prop, var):
    WINDOW.setProperty("%s_%s" % (ADDON_ID, prop), str(var))


def getProperty(prop):
    return WINDOW.getProperty("%s_%s" % (ADDON_ID, prop))


def clearProperty(prop):
    return WINDOW.clearProperty("%s_%s" % (ADDON_ID, prop))
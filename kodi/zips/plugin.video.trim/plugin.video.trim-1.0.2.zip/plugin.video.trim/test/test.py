cmd = 'adb -s <serialnumber> shell ls /system'
print cmd.split()
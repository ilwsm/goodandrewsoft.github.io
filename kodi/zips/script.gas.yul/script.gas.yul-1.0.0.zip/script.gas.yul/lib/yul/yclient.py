import copy
import httplib
import json
import os
import time
import urllib

from gascmtools.logger import log_debug, log
from oauth2client import _helpers
from oauth2client import transport
from oauth2client.client import OAuth2Credentials, _extract_id_token, HttpAccessTokenRefreshError, OAuth2WebServerFlow, _parse_exchange_token_response, FlowExchangeError
from oauth2client.file import Storage

from .exceptions import AccountExistsException
from .ytools import getAccountDir

string_types = (str, unicode)
binary_type = str

class YCredentials(OAuth2Credentials):
    def _do_refresh_request(self, http):
        body = self._generate_refresh_request_body()
        headers = self._generate_refresh_request_headers()

        resp, content = transport.request(
            http, self.token_uri, method='POST',
            body=body, headers=headers)
        content = _helpers._from_bytes(content)

        if resp.status == httplib.OK:
            d = json.loads(content)

            # self.token_response = d
            self.access_token = d['access_token']
            self.refresh_token = d.get('refresh_token', self.refresh_token)
            if 'expires_in' in d:
                seconds = int(d['expires_in'])
                self.token_expiry = seconds + time.time()
            else:
                self.token_expiry = None
            if 'id_token' in d:
                self.id_token = _extract_id_token(d['id_token'])
                self.id_token_jwt = d['id_token']
            else:
                self.id_token = None
                self.id_token_jwt = None
            # On temporary refresh errors, the user does not actually have to
            # re-authorize, so we unflag here.
            self.invalid = False
            if self.store:
                self.store.locked_put(self)
        else:
            error_msg = 'Invalid response {0}.'.format(resp.status)
            try:
                d = json.loads(content)

                if 'error' in d:
                    error_msg = d['error']
                    if 'error_description' in d:
                        error_msg += ': ' + d['error_description']
                    self.invalid = True
                    if self.store is not None:
                        pass
                        # self.store.locked_put(self)
            except (TypeError, ValueError):
                pass
            raise HttpAccessTokenRefreshError(error_msg, status=resp.status)

    @property
    def access_token_expired(self):

        if self.invalid:
            return True

        if not self.token_expiry:
            return False

        now = time.time()
        if now >= self.token_expiry:
            log_debug('access_token is expired. Now: %s, token_expiry: %s', self.token_expiry)
            return True
        return False

    def _to_json(self, strip, to_serialize=None):
        if to_serialize is None:
            to_serialize = copy.copy(self.__dict__)
        else:
            # Assumes it is a str->str dictionary, so we don't deep copy.
            to_serialize = copy.copy(to_serialize)
        for member in strip:
            if member in to_serialize:
                del to_serialize[member]

        for key, val in to_serialize.items():
            if isinstance(val, bytes):
                to_serialize[key] = val.decode('utf-8')
            if isinstance(val, set):
                to_serialize[key] = list(val)
        # return json.dumps(to_serialize)
        return to_serialize

    def to_json(self):
        nsm = frozenset(['store', 'token_response', 'id_token', 'id_token_jwt'])
        return self._to_json(nsm)

    @classmethod
    def from_json(cls, data):
        retval = cls(
            data['access_token'],
            data['client_id'],
            data['client_secret'],
            data['refresh_token'],
            data['token_expiry'],
            data['token_uri'],
            data['user_agent'],
            revoke_uri=data.get('revoke_uri', None),
            id_token=data.get('id_token', None),
            id_token_jwt=data.get('id_token_jwt', None),
            token_response=None,
            scopes=data.get('scopes', None),
            token_info_uri=data.get('token_info_uri', None))
        retval.invalid = data['invalid']
        return retval


class YStorage(Storage):

    @staticmethod
    def getCredentialFile(name):
        accountsDir = getAccountDir()
        return os.path.join(accountsDir, name)

    @staticmethod
    def getAccountsNames():
        return YStorage('')._getAccountsNames()

    def __init__(self, name):
        super(YStorage, self).__init__(YStorage.getCredentialFile('accounts.json'))
        self._data = None
        self.accountName = name

    def setName(self, accountName):
        self.accountName = accountName
        return self

    def getAccountName(self):
        return self.accountName

    def getFilePath(self):
        return self._filename

    def _loadData(self):
        if self._data == None:
            self._forceLoadData()

    def _forceLoadData(self):
        self._create_file_if_needed()
        _helpers.validate_file(self._filename)
        try:
            f = open(self._filename, 'rb')
            content = f.read()
            f.close()
        except IOError:
            raise
        try:
            self._data = json.loads(_helpers._from_bytes(content))
        except ValueError as e:
            log_debug(e)
            self._data = dict()

    def _saveData(self):
        self._create_file_if_needed()
        _helpers.validate_file(self._filename)
        f = open(self._filename, 'w')
        f.write(json.dumps(self._data))
        f.close()

    def _getAccountsNames(self):
        self._loadData()
        accounts = self._data
        list = []
        for acc in accounts:
            list.append(accounts[acc]['name'])
        return list

    def _getAccount(self):
        accounts = self._data
        for acc in accounts:
            if self.accountName == accounts[acc]['name']:
                return accounts[acc]
        return None

    def getAccountId(self):
        self._loadData()
        return self._getAccount()['refresh_token']

    def switchAccount(self, account_id):
        self._loadData()
        accounts = self._data
        for acc in accounts:
            if account_id == accounts[acc]['refresh_token']:
                self.accountName = accounts[acc]['name']
                return
        raise

    def _getAccountIndex(self):
        accounts = self._data
        for acc in accounts:
            if self.accountName == accounts[acc]['name']:
                return acc
        return None

    def locked_get(self):
        self._loadData()
        credentials = None
        acc = self._getAccount()
        if acc:
            credentials = YCredentials.from_json(acc)
            credentials.set_store(self)
        return credentials

    def locked_put(self, credentials):
        self._loadData()
        index = self._getAccountIndex()
        if index is None:
            index = str(len(self._data))

        accounts = self._data
        accounts[index] = credentials.to_json()
        accounts[index]['name'] = self.accountName
        self._saveData()

    def checkIfAccountExist(self):
        self._loadData()
        if self._getAccountIndex() is not None:
            raise AccountExistsException()

    def locked_add(self, credentials):
        self.checkIfAccountExist()
        index = str(len(self._data))
        accounts = self._data
        accounts[index] = credentials.to_json()
        accounts[index]['name'] = self.accountName
        self._saveData()

    def locked_rename(self, dst):
        self._loadData()
        account = self._getAccount()
        account['name'] = dst
        self._saveData()

    def locked_remove(self, arg=None):
        self._loadData()
        index = self._getAccountIndex()
        accounts = self._data
        del accounts[index]
        self._saveData()

    def put(self, credentials):
        self._modifyData(self.locked_put, credentials)

    def add(self, credentials):
        self._modifyData(self.locked_add, credentials)

    def rename(self, dst):
        self._modifyData(self.locked_rename, dst)

    def remove(self):
        self._modifyData(self.locked_remove, None)

    def _modifyData(self, func, arg):
        self.acquire_lock()
        try:
            func(arg)
        finally:
            self.release_lock()


class YWebServerFlow(OAuth2WebServerFlow):
    def step2_exchange(self, code=None, http=None, device_flow_info=None):
        if code is None and device_flow_info is None:
            raise ValueError('No code or device_flow_info provided.')
        if code is not None and device_flow_info is not None:
            raise ValueError('Cannot provide both code and device_flow_info.')

        if code is None:
            code = device_flow_info.device_code
        elif not isinstance(code, (string_types, binary_type)):
            if 'code' not in code:
                raise FlowExchangeError(code.get(
                    'error', 'No code was supplied in the query parameters.'))
            code = code['code']

        post_data = {
            'client_id': self.client_id,
            'code': code,
            'scope': self.scope,
        }
        if self.client_secret is not None:
            post_data['client_secret'] = self.client_secret
        if self._pkce:
            post_data['code_verifier'] = self.code_verifier
        if device_flow_info is not None:
            post_data['grant_type'] = 'http://oauth.net/grant_type/device/1.0'
        else:
            post_data['grant_type'] = 'authorization_code'
            post_data['redirect_uri'] = self.redirect_uri
        body = urllib.urlencode(post_data)
        headers = {
            'content-type': 'application/x-www-form-urlencoded',
        }
        if self.authorization_header is not None:
            headers['Authorization'] = self.authorization_header
        if self.user_agent is not None:
            headers['user-agent'] = self.user_agent

        if http is None:
            http = transport.get_http_object()

        resp, content = transport.request(
            http, self.token_uri, method='POST', body=body, headers=headers)
        d = _parse_exchange_token_response(content)
        if resp.status == httplib.OK and 'access_token' in d:
            access_token = d['access_token']
            refresh_token = d.get('refresh_token', None)
            if not refresh_token:
                log_debug(
                    'Received token response with no refresh_token. Consider '
                    "reauthenticating with prompt='consent'.")
            token_expiry = None
            if 'expires_in' in d:
                seconds = int(d['expires_in'])
                token_expiry = seconds + time.time()

            extracted_id_token = None
            id_token_jwt = None
            if 'id_token' in d:
                extracted_id_token = _extract_id_token(d['id_token'])
                id_token_jwt = d['id_token']

            log_debug('Successfully retrieved access token')
            return YCredentials(
                access_token, self.client_id, self.client_secret,
                refresh_token, token_expiry, self.token_uri, self.user_agent,
                revoke_uri=self.revoke_uri, id_token=extracted_id_token,
                id_token_jwt=id_token_jwt, token_response=None, scopes=self.scope,
                token_info_uri=self.token_info_uri)
        else:
            log_debug('Failed to retrieve access token: %s', content)
            if 'error' in d:
                # you never know what those providers got to say
                error_msg = (str(d['error']) +
                             str(d.get('error_description', '')))
            else:
                error_msg = 'Invalid response: {0}.'.format(str(resp.status))
            raise FlowExchangeError(error_msg)

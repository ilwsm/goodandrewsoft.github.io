import httplib
import random
import time

import httplib2
import ytools
from .exceptions import CancelledException
from gasutils import utils

from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaFileUpload
from oauth2client import client
from yclient import YWebServerFlow
from . import getString, log

YOUTUBE_UPLOAD_SCOPE = ["https://www.googleapis.com/auth/youtube.upload", "https://www.googleapis.com/auth/youtube"]
YOUTUBE_API_SERVICE_NAME = "youtube"
YOUTUBE_API_VERSION = "v3"

# Always retry when these exceptions are raised.
RETRIABLE_EXCEPTIONS = (httplib2.HttpLib2Error, IOError, httplib.NotConnected,
                        httplib.IncompleteRead, httplib.ImproperConnectionState,
                        httplib.CannotSendRequest, httplib.CannotSendHeader,
                        httplib.ResponseNotReady, httplib.BadStatusLine)

# Always retry when an apiclient.errors.HttpError with one of these status
# codes is raised.
RETRIABLE_STATUS_CODES = [500, 502, 503, 504]

httplib2.RETRIES = 1

# Maximum number of times to retry before giving up.
MAX_RETRIES = 10


def flowFromClientsecrets():
    client_id, client_secret = ytools.get_api_keys()

    constructor_kwargs = {
        'redirect_uri': None,
        'user_agent': u'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36',
        'auth_uri': u'https://accounts.google.com/o/oauth2/auth',
        'token_uri': u'https://oauth2.googleapis.com/token',
        'login_hint': None
    }

    return YWebServerFlow(client_id, client_secret, YOUTUBE_UPLOAD_SCOPE, **constructor_kwargs)


def get_authenticated_service(storage):
    credentials = storage.get()

    if credentials is None or credentials.invalid:
        # credentials = createCredentails(storage)
        raise Exception("credentials is None or credentials.invalid")

    http = credentials.authorize(httplib2.Http())
    b = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION, http=http)
    return b


def createCredentails(storage):
    import xbmc, xbmcgui
    utils.activateBusyDialog()
    try:
        flow = flowFromClientsecrets()
        deviceFlowInfo = flow.step1_get_device_and_user_codes()
        verification_url = deviceFlowInfo.verification_url.lstrip('https://www.')
        interval = deviceFlowInfo.interval
        if interval > 60:
            interval = 5
        totalSteps = steps = ((10 * 60) / interval)  # 10 Minutes
        # log_debug("user_code:%s, verification_url:%s, interval:%d, steps:%d" % (deviceFlowInfo.user_code, verification_url, interval, steps))
        text = [
            getString(30518) % utils.bold(verification_url),
            '[CR]%s %s' % (getString(30519), utils.bold(deviceFlowInfo.user_code))
        ]
    finally:
        utils.closeBusyDialog()

    pDialog = xbmcgui.DialogProgress()
    pDialog.create(getString(30500), ''.join(text))
    while 1:
        try:
            pDialog.update((totalSteps - steps) * 100 / totalSteps)
            steps -= 1
            if pDialog.iscanceled():
                pDialog.close()
                raise CancelledException('Dialog is cancelled')
            credentials = flow.step2_exchange(device_flow_info=deviceFlowInfo)
            pDialog.close()
            storage.add(credentials)
            credentials.set_store(storage)
            return credentials
        except client.FlowExchangeError as e:
            if steps > 0 and e.message.startswith('authorization_pending'):
                time.sleep(interval)
                continue
            raise


def initialize_upload(youtube, job, callback):
    tags = None

    args = job.args
    if args['keywords']:
        tags = args['keywords'].split(",")

    body = dict(
        snippet=dict(
            title=args['title'],
            description=args['description'],
            tags=tags,
            categoryId=args['category']
        ),
        status=dict(
            privacyStatus=args['privacyStatus']
        )
    )
    media_body = MediaFileUpload(args['file'], chunksize=4 * 1024 * 1024, resumable=True)
    insert_request = youtube.videos().insert(
        part=",".join(body.keys()),
        body=body,
        media_body=media_body
    )
    insert_request.resumable_uri = job.opt['resumable_uri']
    insert_request.resumable_progress = job.opt['resumable_progress']

    job._request = insert_request
    yid = resumable_upload(insert_request, callback)
    media_body._fd.close()
    return yid


def resumable_upload(insert_request, callback):
    error = None
    retry = 0
    while 1:
        try:
            log.debug("Uploading file...")
            status, response = insert_request.next_chunk()
            if status:
                callback.update(status.total_size, status.resumable_progress)
            if response:
                if 'id' in response:
                    # log_debug ("Video id '%s' was successfully uploaded." % response['id'])
                    return response['id']
                else:
                    raise Exception("The upload failed with an unexpected response: %s" % response)
        except HttpError as e:
            if e.resp.status in RETRIABLE_STATUS_CODES:
                error = "A retriable HTTP error %d occurred:\n%s" % (e.resp.status,
                                                                     e.content)
            else:
                raise
        except RETRIABLE_EXCEPTIONS as e:
            error = "A retriable error occurred: %s" % e

        if error is not None:
            log.debug(error)
            retry += 1
            if retry > MAX_RETRIES:
                exit("No longer attempting to retry.")

            max_sleep = 2 ** retry
            sleep_seconds = random.random() * max_sleep
            log.debug("Sleeping %f seconds and then retrying..." % sleep_seconds)
            time.sleep(sleep_seconds)

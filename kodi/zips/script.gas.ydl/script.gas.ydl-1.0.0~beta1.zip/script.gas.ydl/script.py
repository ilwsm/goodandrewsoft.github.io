import sys


def main():
    if sys.argv[1] == 'updatecore':
        import xbmc
        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
        from lib.ydl.updater import updateCoreWithCallback
        updateCoreWithCallback()


if __name__ == '__main__':

    if len(sys.argv) < 2:
        exit()
    else:
        main()

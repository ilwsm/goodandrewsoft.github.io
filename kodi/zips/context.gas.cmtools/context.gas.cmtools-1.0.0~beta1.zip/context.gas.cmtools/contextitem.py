# coding=utf-8
import json
import sys

import xbmc
from gasutils import DIALOG

from lib.gascmtools import getString, ADDON


def getPath(li):
    def getFilePath(method, name, id):
        params = {'properties': ['file']}
        data = {'jsonrpc': '2.0', 'params': params, 'id': '1'}
        data['method'] = method
        params[name + 'id'] = id
        deserialization = json.loads(xbmc.executeJSONRPC(json.dumps(data)))
        return deserialization['result'][name + 'details']['file']

    content = xbmc.getInfoLabel('Container.Content')
    # from gasutils.logger import log
    # log("content:%s, vid:%s, aid:%s, path:%s" % (content, li.getVideoInfoTag().getDbId(), li.getMusicInfoTag().getDbId(), li.getPath()))
    # exit()

    path = pluginPath = li.getPath().decode('UTF-8')
    if (path[0] == '/' or path[1] == ':'):
        filePath = path
    elif content == "movies":
        filePath = getFilePath('VideoLibrary.GetMovieDetails', 'movie', li.getVideoInfoTag().getDbId())
    elif content == "episodes":
        filePath = getFilePath('VideoLibrary.GetEpisodeDetails', 'episode', li.getVideoInfoTag().getDbId())
    elif content == "songs":
        filePath = getFilePath('AudioLibrary.GetSongDetails', 'song', li.getMusicInfoTag().getDbId())
    else:
        filePath = None

    return filePath, pluginPath


def runYdl(path):
    try:
        from ydlrun import exrun
    except ImportError:
        xbmc.executebuiltin('InstallAddon(script.gas.ydl)')
    else:
        exrun(path)


def runYul(path):
    try:
        from yulrun import exrun
    except ImportError:
        xbmc.executebuiltin('InstallAddon(script.gas.yul)')
    else:
        exrun(path)


if __name__ == '__main__':
    # content:videos, vid:-1, aid:-1, path:plugin://plugin.video.youtube/play/?video_id=u2DdAM94CVU
    # content:movies, vid:27, aid:-1, path:videodb://recentlyaddedmovies/27
    # content:movies, vid:-1, aid:-1, path:plugin://plugin.video.hdrezka.tv/?mode=show&url=http%3a%2f%2fhdrezka.tv%2ffilms%2fdrama%2f32041-katcelmaher-1969.html
    # content:episodes, vid:690, aid:-1, path:videodb://tvshows/titles/39/-2/690?season=-2&tvshowid=39
    # content:files, vid:-1, aid:-1, path:D:\Sound\music\Alizee_-_Mademoiselle_Juliette.mp3
    # content:songs, vid:-1, aid:240, path:musicdb://songs/240.mp3

    li = sys.listitem
    filePath, pluginPath = getPath(li)
    dialogsItems = list()
    funcList = list()
    if pluginPath:
        if ADDON.getSettingBool('enable_ydl') and pluginPath.startswith('plugin://plugin.video.youtube/play/?video_id'):
            dialogsItems.append(getString(30124))
            funcList.append(lambda: runYdl(pluginPath))

    if filePath:
        if ADDON.getSettingBool('enable_yul'):
            dialogsItems.append(getString(30104))
            funcList.append(lambda: runYul(filePath))

    dialogsItems.append(getString(30125))
    ret = DIALOG.contextmenu(dialogsItems)
    if ret == -1:
        exit()

    if ret == len(dialogsItems) - 1:
        DIALOG.ok("Dialog", "To Do")
        # import xbmcvfs
        # xbmcvfs.delete(filePath)
        # xbmc.executebuiltin("Container.Refresh")
    else:
        funcList[ret]()

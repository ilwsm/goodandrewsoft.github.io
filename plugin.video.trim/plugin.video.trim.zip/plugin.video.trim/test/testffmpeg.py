import subprocess
import re
import collections

progress_pattern = re.compile(
    r'time\s*\=\s*(\S+)'
)

duration_pattern = re.compile(
    r'(Duration|start|bitrate):\s*([^,\n]*)'
)

Progress = collections.namedtuple('Progress', [
    'frame', 'fps', 'size', 'time', 'bitrate', 'speed'
])

Duration = collections.namedtuple('Duration', [
    'duration', 'start', 'bitrate'
])


def parse_progress(line):
    items = {
        key: value for key, value in progress_pattern.findall(line)
    }

    if not items:
        return None

    return Progress(
        frame=int(items['frame']),
        fps=float(items['fps']),
        size=int(items['size'].replace('kB', '')) * 1024,
        time=items['time'],
        bitrate=float(items['bitrate'].replace('kbits/s', '')),
        speed=float(items['speed'].replace('x', '')),
    )


def parse_duration(line):
    items = {
        key: value for key, value in duration_pattern.findall(line)
    }

    if not items:
        return None

    return Duration(
        duration=items['Duration'],
        start=items['start'],
        bitrate=items['bitrate']
    )


def method_name():
    cmd = "F:/Run/Internet/Download Master/Application Data/ffmp2eg.exe -i J:/tt.mp4 -y J:/tt.avi"

    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)

    if p != None:
        p.terminate()
        raise Exception([3, 'A very specific bad thing happened.'])

    for line in iter(p.stdout.readline, ""):
        if not line: break
        time = progress_pattern.findall(line)
        if (time): print(time[0].split(':'))


try:
    method_name()
except OSError as e:
    print type(e)
except Exception as e:
    print e.args

# ('time', '00:00:01.85')

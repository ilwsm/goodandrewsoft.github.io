class CanceledException(Exception):
    pass

class UpdateCoreException(Exception):
    pass
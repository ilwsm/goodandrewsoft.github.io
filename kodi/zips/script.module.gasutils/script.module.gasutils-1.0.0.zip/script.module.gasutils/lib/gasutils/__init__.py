import xbmc
import xbmcvfs

import xbmcaddon, xbmc, xbmcgui

from .utils import closeBusyDialog, activateBusyDialog

WINDOW = xbmcgui.Window(10000)


class _DIALOG(xbmcgui.Dialog):

    def ok_cbd(self, *args, **kwargs):
        closeBusyDialog()
        return self.ok(*args, **kwargs)

    def yesno_cbd(self, *args, **kwargs):
        closeBusyDialog()
        r = self.yesno(*args, **kwargs)
        if r:
            activateBusyDialog()
        return r

    def select_cbd(self, *args, **kwargs):
        closeBusyDialog()
        r = self.select(*args, **kwargs)
        if r != -1:
            activateBusyDialog()
        return r


DIALOG = _DIALOG()
MONITOR = xbmc.Monitor()

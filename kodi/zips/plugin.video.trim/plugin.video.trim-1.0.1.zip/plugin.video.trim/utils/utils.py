import xbmc, os, platform
from sqlite3 import dbapi2 as sqlite

def log(var):
    xbmc.log("[FR]:" + str(var), 2)


def secToTimeStr(seconds, sep=':'):
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    return '{0:02d}{3}{1:02d}{3}{2:02d}'.format(h, m, s, sep)

def deleteFile(path):
    try:
        os.remove(path)
    except:
        pass


def getKodiVer():
    build = xbmc.getInfoLabel("System.BuildVersion")
    return int(build.split()[0][:2])

def getOS():
    os = None
    system = None
    platform = None

    try:
        system = platform.system()
    except:
        pass

    try:
        platform = platform.platform()
    except:
        pass

    if xbmc.getCondVisibility("system.platform.android"):
        os = "android"
    elif xbmc.getCondVisibility("system.platform.linux"):
        os = "linux"
    elif xbmc.getCondVisibility("system.platform.xbox"):
        os = "windows"
    elif xbmc.getCondVisibility("system.platform.windows"):
        os = "windows"
    elif system == "Darwin":
        os = "darwin"
        if "AppleTV" in platform:
            os = "ios"
        elif xbmc.getCondVisibility("system.platform.ios"):
            os = "ios"
    return os

def getDb():
    dbPath = os.path.join(xbmc.translatePath("special://database"), 'MyVideos116.db')
    return sqlite.connect(dbPath)
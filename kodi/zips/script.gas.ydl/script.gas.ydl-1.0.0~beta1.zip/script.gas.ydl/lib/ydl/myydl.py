import youtube_dl
from youtube_dl.postprocessor.common import PostProcessor

class MyYoutubeDl(youtube_dl.YoutubeDL):

    def list_formats(self, info_dict):
        self.to_screen(info_dict.get('formats', [info_dict]))


class MyPostProcessor(PostProcessor):
    def __init__(self, callback):
        super(MyPostProcessor, self).__init__(None)
        self.callback = callback

    def run(self, information):
        self.callback.run(information)
        return super(MyPostProcessor, self).run(information)
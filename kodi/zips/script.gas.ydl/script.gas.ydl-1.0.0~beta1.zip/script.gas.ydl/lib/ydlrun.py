def exrun(filePath):
    from ydl import task
    task.run(filePath)

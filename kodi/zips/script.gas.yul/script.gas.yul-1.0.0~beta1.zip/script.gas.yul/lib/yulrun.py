def exrun(filePath):
    from yul import task
    task.run(filePath)

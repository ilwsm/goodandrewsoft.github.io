# coding=utf-8

import sys, os
import xbmc, xbmcaddon, xbmcgui

from utils.utils import log
from utils import ffmpeg
from utils import utils

addon = xbmcaddon.Addon()
getString = addon.getLocalizedString

dialog = xbmcgui.Dialog()

def showErrorDialog(text):
    dialog.textviewer('ErrorDialog', str(text))

def properExit(cursor, db):
    cursor.close()
    db.close()
    exit()

def callback(pDialog, overallTime, time):
    # log("overallTime" + str(overallTime))
    # log("time" + str(time))
    global globalUpdateString
    pDialog.update(int((time * 100) / overallTime), '%s%s' % (getString(30004), globalUpdateString))


if __name__ == '__main__':
    li = sys.listitem

    db = utils.getDb()

    inputVideoFile = li.getPath().decode('UTF-8')

    dirPath = os.path.dirname(inputVideoFile) + os.sep
    basename = os.path.basename(inputVideoFile)

    cursor = db.execute('SELECT timeInSeconds, idFile FROM main.bookmark WHERE idFile='
                        '(SELECT idFile FROM main.files WHERE idPath=(SELECT idPath FROM main.path WHERE strPath=?) AND strFilename=?) '
                        'AND thumbNailImage <> ? ORDER BY timeInSeconds', (dirPath, basename, '',))

    ctimeCodes = cursor.fetchall()
    log(ctimeCodes)

    length = len(ctimeCodes)
    if (length > 0):
        idFile = ctimeCodes[0][1]
        outputVideoFile = ''
        ret = None
        tc = []
        x = None
        stts = utils.secToTimeStr
        tc.append('%s - %s' % (getString(30008), stts(ctimeCodes[0][0])))
        for x in range(0, length - 1):
            tc.append('%s - %s' % (stts(ctimeCodes[x][0]), stts(ctimeCodes[x + 1][0])))
        tc.append('%s - %s' % (stts(ctimeCodes[length - 1][0]), getString(30009)))

        dret = dialog.multiselect(getString(30005), tc)
        if (dret == None):
            properExit(cursor, db)

        savingRet = 0

        opath = addon.getSetting('opath')
        if (opath != '[current]'):
            parts = os.path.splitext(opath + basename)
        else:
            if (len(dret) == 1):
                savingRet = dialog.select('Method for saving', ["As new", "Overwrite"])
                if (savingRet == -1): properExit(cursor, db)
            parts = os.path.splitext(inputVideoFile)

        pDialog = xbmcgui.DialogProgress()
        pDialog.create(getString(30002), getString(30004))
        result = True
        i = 0
        for ret in dret:
            i = i + 1
            globalUpdateString = ' File (%d/%d)' % (i, len(dret))
            if (ret == 0):
                timeCodes = [0.00, ctimeCodes[0][0]]
                tc[ret] = '%s - %s' % ('BOF', stts(timeCodes[1], '-'))
            elif (ret == length):
                timeCodes = [ctimeCodes[length - 1][0]]
                tc[ret] = '%s - %s' % (stts(timeCodes[0], '-'), 'EOF')
            else:
                timeCodes = [ctimeCodes[ret - 1][0], ctimeCodes[ret][0]]
                tc[ret] = '%s - %s' % (stts(timeCodes[0], '-'), stts(timeCodes[1], '-'))

            outputVideoFile = parts[0] + ' (' + tc[ret] + ')' + parts[1]

            try:
                result = ffmpeg.start_ffmpeg(pDialog, callback, addon.getSetting('ffmpeg'), inputVideoFile, timeCodes, outputVideoFile)
            except OSError as e:
                result = False
                pDialog.close()
                dialog.ok(getString(30013), str(e))
                break
            except NotImplementedError as e:
                result = False
                break

        pDialog.close()
        if (result == True):
            deletebookmarks = False
            if (savingRet == 1):
                try:
                    os.remove(inputVideoFile)
                    os.rename(outputVideoFile, inputVideoFile)
                    deletebookmarks = True
                except Exception as e:
                    raise e
            else:
                deletebookmarks = addon.getSetting('deletebookmarks') == "true"

            if (deletebookmarks):
                try:
                    cursor.execute('SELECT thumbNailImage FROM main.bookmark WHERE idFile=? AND thumbNailImage <> ?', (idFile, '',))
                    for img in cursor.fetchall():
                        utils.deleteFile(xbmc.translatePath(img[0]))
                    cursor.execute('DELETE FROM "main"."bookmark" WHERE idFile=?', (idFile,))
                    db.commit()
                except Exception as e:
                    dialog.ok(getString(30018), str(e))
        xbmc.executebuiltin("Container.Refresh")
    else:
        dialog.ok(getString(30000), getString(30001))

    properExit(cursor, db)

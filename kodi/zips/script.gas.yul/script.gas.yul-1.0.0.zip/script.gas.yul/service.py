# -*- coding: utf-8 -*-
import os
import sys

from lib import yul
from lib.yul import task

if __name__ == '__main__':
    if yul.ADDON.getSetting('resume_after_start') == 'true':
        task.run(None)



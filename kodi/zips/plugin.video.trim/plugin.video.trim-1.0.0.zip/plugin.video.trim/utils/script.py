import os
import platform
import shutil
import sys

import xbmc, xbmcaddon, xbmcgui

from utils import log


def android_get_current_appid():
    with open("/proc/%d/cmdline" % os.getpid()) as fp:
        return fp.read().rstrip("\0")


def get_platform():
    build = xbmc.getInfoLabel("System.BuildVersion")
    kodi_version = int(build.split()[0][:2])

    ret = {
        "auto_arch": sys.maxsize > 2 ** 32 and "64-bit" or "32-bit",
        "arch": sys.maxsize > 2 ** 32 and "x64" or "x86",
        "os": "",
        "version": "",
        "kodi": kodi_version,
        "build": build,
        "fork": True,
        "machine": "",
        "system": "",
        "platform": ""
    }

    try:
        ret["os"] = platform.release()
    except:
        pass

    try:
        ret["machine"] = platform.machine()
    except:
        # Default 'machine' for Android can be 'arm'
        if xbmc.getCondVisibility("system.platform.android"):
            ret["machine"] = "arm"
        pass

    try:
        ret["system"] = platform.system()
    except:
        pass

    try:
        ret["platform"] = platform.platform()
    except:
        pass

    if xbmc.getCondVisibility("system.platform.android"):

        ret["os"] = "android"
        if "arm" in ret["machine"].lower() or "aarch" in ret["machine"].lower():
            ret["arch"] = "arm"
            if "64" in ret["machine"] and ret["auto_arch"] == "64-bit":
                ret["arch"] = "arm64"
    elif xbmc.getCondVisibility("system.platform.linux"):
        ret["os"] = "linux"

        if "aarch" in ret["machine"].lower() or "arm64" in ret["machine"].lower():

            if xbmc.getCondVisibility("system.platform.linux.raspberrypi"):
                ret["arch"] = "armv7"
            elif ret["auto_arch"] == "32-bit":
                ret["arch"] = "armv7"
            elif ret["auto_arch"] == "64-bit":
                ret["arch"] = "arm64"
            # elif platform.architecture()[0].startswith("32"):
            #     ret["arch"] = "armv6"
            else:
                ret["arch"] = "armv7"
        elif "armv7" in ret["machine"]:
            ret["arch"] = "armv7"
        elif "arm" in ret["machine"]:
            cpuarch = ""
            if "aarch" in ret["machine"].lower() or "arm" in ret["machine"].lower():
                info = cpuinfo()
                for proc in info.keys():
                    model = ""
                    if "model name" in info[proc]:
                        model = info[proc]["model name"].lower()
                    elif "Processor" in info[proc]:
                        model = info[proc]["Processor"].lower()

                    if model:
                        if "aarch" in model or "arm64" in model or "v8l" in model:
                            cpuarch = "arm64"
                        elif "armv7" in model or "v7l" in model:
                            cpuarch = "armv7"
                        break

            if cpuarch:
                ret["arch"] = cpuarch
            else:
                ret["arch"] = "armv6"
    elif xbmc.getCondVisibility("system.platform.xbox"):
        ret["os"] = "windows"
        ret["arch"] = "x64"
        ret["fork"] = False
    elif xbmc.getCondVisibility("system.platform.windows"):
        ret["os"] = "windows"
        if ret["machine"].endswith('64'):
            ret["arch"] = "x64"
    elif ret["system"] == "Darwin":

        ret["os"] = "darwin"
        ret["arch"] = "x64"

        if "AppleTV" in ret["platform"]:
            ret["os"] = "ios"
            ret["arch"] = "armv7"
            ret["fork"] = False
            if "64bit" in ret["platform"]:
                ret["arch"] = "arm64"
        elif xbmc.getCondVisibility("system.platform.ios"):
            ret["os"] = "ios"
            ret["arch"] = "armv7"
            ret["fork"] = False
            if "64bit" in ret["platform"]:
                ret["arch"] = "arm64"

    # elif xbmc.getCondVisibility("system.platform.osx"):
    #     ret["os"] = "darwin"
    #     ret["arch"] = "x64"
    # elif xbmc.getCondVisibility("system.platform.ios"):
    #     ret["os"] = "ios"
    #     ret["arch"] = "armv7"
    return ret

def cpuinfo():
    cpuinfo = {}
    procinfo = {}
    nprocs = 0
    with open('/proc/cpuinfo') as f:
        for line in f:
            if not line.strip():
                cpuinfo['proc%s' % nprocs] = procinfo
                nprocs = nprocs + 1
            else:
                if len(line.split(':')) == 2:
                    procinfo[line.split(':')[0].strip()] = line.split(':')[1].strip()
                else:
                    procinfo[line.split(':')[0].strip()] = ''
    return cpuinfo


PLATFORM = get_platform()

ADDON = xbmcaddon.Addon()

ADDON_ID = ADDON.getAddonInfo("id")
getString = ADDON.getLocalizedString

def findFFMPEGpath():
    if PLATFORM["os"] != "android":
        return 'ffmpeg'

    app_id = android_get_current_appid()
    xbmc_data_path = os.path.join("/data", "data", app_id)
    if not os.path.exists(xbmc_data_path):
        raise Exception(xbmc_data_path + " not exist")

    dest_binary_dir = os.path.join(xbmc_data_path, "files", ADDON_ID, "bin", "%(os)s_%(arch)s" % PLATFORM)

    dest_binary_path = os.path.join(dest_binary_dir, 'ffmpeg')
    # log('---------------------')
    # log("dest_binary_dir:" + str(dest_binary_dir))
    # log("dest_binary_path:" + dest_binary_path)

    ffmpegValid = os.path.isfile(dest_binary_path) and os.access(dest_binary_path, os.X_OK)

    if (ffmpegValid):
        ret = xbmcgui.Dialog().select(getString(30020),
                                      [getString(30021), getString(30022)])
    else:
        ret = xbmcgui.Dialog().yesno(getString(30023),
                                     getString(30024),
                                     getString(30025))

    if ret == 1:
        try:
            os.makedirs(dest_binary_dir)
        except OSError as e:
            shutil.rmtree(dest_binary_dir)
            os.makedirs(dest_binary_dir)
        try:
            fetch_ffmpeg(dest_binary_path)
        except NotImplementedError:
            exit()
        os.chmod(dest_binary_path, 0o700)
        xbmcgui.Dialog().ok(getString(30000), getString(30019))
    return dest_binary_path


def fetch_ffmpeg(dest_binary_path):
    # if os.system('cp /data/local/tmp/ffmpeg.bin %s' % (dest_binary_path,)) != 0:
    #     raise NotImplementedError('Cannot copy ffmpeg binary')
    import urllib

    def DownloaderClass(url, dest):
        dp = xbmcgui.DialogProgress()
        dp.create(getString(30026), getString(30027), url)
        urllib.urlretrieve(url, dest, lambda nb, bs, fs, url=url: _pbhook(nb, bs, fs, url, dp))

    def _pbhook(numblocks, blocksize, filesize, url=None, dp=None):
        try:
            percent = min((numblocks * blocksize * 100) / filesize, 100)
            dp.update(percent)
        except:
            percent = 100
            dp.update(percent)
        if dp.iscanceled():
            dp.close()
            raise NotImplementedError("DOWNLOAD CANCELLED")

    if 'arm' in PLATFORM['arch']:
        url = 'https://goodandrewsoft.github.io/kodi/ffmpeg/arm/ffmpeg'
    else:
        url = 'https://goodandrewsoft.github.io/kodi/ffmpeg/x86/ffmpeg'

    DownloaderClass(url, dest_binary_path)

if len(sys.argv) > 1:
    addon = xbmcaddon.Addon()
    if (sys.argv[1] == "reset_ffmpeg"):
        addon.setSetting('ffmpeg', findFFMPEGpath())
    elif (sys.argv[1] == "reset_opath"):
        addon.setSetting('opath', "[current]")

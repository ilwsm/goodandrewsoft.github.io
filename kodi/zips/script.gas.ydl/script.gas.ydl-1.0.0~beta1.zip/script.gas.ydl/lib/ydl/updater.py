# -*- coding: utf-8 -*-
import os
import tarfile
import urllib
import urllib2

import xbmc
from gasutils.utils import make_dirs_if_not_exist

from . import ADDON, getString, log
from .exceptions import UpdateCoreException

VERSION_URL = 'https://yt-dl.org/latest/version'


def getCurrentVersion():
    import sys
    try:
        from youtube_dl import version
        if (sys.version_info > (3, 0)):
            import importlib
            importlib.reload(version)
        else:
            reload(version)

        return version.__version__
    except:
        return None


def getNewVersion():
    try:
        return urllib2.urlopen(VERSION_URL).read().strip()
    except:
        raise UpdateCoreException("Cannot determine new version core")


def updateCore(callback, currentVersion=getCurrentVersion(), newVersion=None):
    callback.start('[coreupdater]', 'Checking for new youtube_dl core version...')
    if not newVersion:
        newVersion = getNewVersion()

    if currentVersion == newVersion:
        raise UpdateCoreException("Core version up to date")

    callback.update('[coreupdater]', 'Updating youtube_dl core to new version: {0}'.format(newVersion))
    # log('[coreupdater]Updating youtube_dl core to new version: {0}'.format(newVersion))

    profile = xbmc.translatePath(ADDON.getAddonInfo('profile')).decode('utf-8')

    make_dirs_if_not_exist(profile)

    newVersionArchiveName = "youtube-dl-%s.tar.gz" % newVersion
    archivePath = os.path.join(profile, 'youtube-dl.tar.gz')
    extractedPath = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('path')).decode('utf-8'), 'lib', 'ydl')

    corePath = os.path.join(extractedPath, 'youtube_dl')
    if os.path.exists(corePath):
        import shutil
        shutil.rmtree(corePath, ignore_errors=True)
        callback.update('[coreupdater]', 'Old version removed. Downloading the new...')

    latestUrl = 'https://yt-dl.org/latest/%s' % newVersionArchiveName

    urllib.urlretrieve(latestUrl, archivePath, lambda nb, bs, fs, url=latestUrl: callback.coreHook(nb, bs, fs, url))

    def members(tf):
        for member in tf.getmembers():
            if member.path.startswith('youtube-dl/youtube_dl'):
                member.path = member.path[11:]
                yield member

    callback.update('[coreupdater]', 'Extracting core')
    with tarfile.open(archivePath, mode='r:gz') as tf:
        tf.extractall(path=extractedPath, members=members(tf))

    from gasutils.utils import deleteFile
    deleteFile(os.path.join(profile, archivePath))
    callback.update('[coreupdater]', 'Core update complete !')

def tryUpdate(callback):
    from gasutils import DIALOG
    try:
        currentVersion = getCurrentVersion()
        newVersion = getNewVersion()
        curCoresStr = getString(32025) % currentVersion
        newCoresStr = getString(32030) % newVersion
        if currentVersion == newVersion:
            DIALOG.ok_cbd(getString(32024), curCoresStr, newCoresStr, getString(32031))
        elif DIALOG.yesno_cbd(getString(32024), curCoresStr, newCoresStr, getString(32032)):
            updateCore(callback, currentVersion, newVersion)
            callback.close()
            updatedVersion = getCurrentVersion()
            if newVersion == updatedVersion:
                DIALOG.ok_cbd(getString(32024), getString(32033) % updatedVersion)
            else:
                raise UpdateCoreException("Failed update core! Current Core Version: %s" % updatedVersion + ", New Core Version: %s" % newVersion)
    except Exception as e:
        log.error(e)
        DIALOG.ok_cbd(getString(32023), getString(32022))

# updateCore()
def updateCoreWithCallback():
    from .callback import MyCallback
    callback = MyCallback(lambda: None)
    tryUpdate(callback)

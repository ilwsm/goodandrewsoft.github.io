# coding=utf-8

import os
import time

import playlists
import xbmc
import xbmcgui
from gasutils import utils, DIALOG, MONITOR
from googleapiclient.errors import HttpError

from . import getProperty, setProperty, clearProperty, getString, ADDON, DATA_DIR, log
from .exceptions import CancelledException, CurrentJobCancelException
from .uploader import get_authenticated_service, initialize_upload
from .yclient import YStorage
from .yjobs import YJobsLab, Job
from .ytools import getUploadPrivacy, getUploadCategrory, createAccount, jobMaintenance


def stopIfNeed():
    prop = getProperty('stop')
    if MONITOR.abortRequested():
        exit()
    elif prop:
        if prop == 'deleteCurrent':
            raise CurrentJobCancelException
        exit()


class DialogCallback(object):

    def __init__(self, text):
        self.dialog = xbmcgui.DialogProgressBG()
        self.resume_len = 0
        self.startTime = None
        self.heading = text
        self.preLine = getString(30144)
        self.dialog.create(text, self.preLine)

    def start(self, text='', resumeLen=0):
        self.heading = text
        self.resume_len = resumeLen
        self.startTime = time.time()

    def update(self, total_size, byte_counter):
        stopIfNeed()
        if not self.startTime:
            self.start()

        now = time.time()
        speed = self.calc_speed(self.startTime, now, byte_counter - self.resume_len)
        eta = self.calc_eta(self.startTime, now, total_size - self.resume_len, byte_counter - self.resume_len)
        elapsed = now - self.startTime

        message = ['%s ' % self.preLine]
        if speed:
            message.append(utils.simpleSize(speed) + 's - ')
        if eta:
            message.append(' ETA: ' + utils.durationToShortText(eta) + '  |  ')

        message.append('(' + utils.simpleSize(byte_counter) + '/' + utils.simpleSize(total_size) + ')')
        self.dialog.update(100 * byte_counter / total_size, self.heading, ''.join(message))

    def close(self):
        self.dialog.close()

    def __del__(self):
        self.close()

    @staticmethod
    def calc_speed(start, now, bytes):
        dif = now - start
        if bytes == 0 or dif < 0.001:  # One millisecond
            return None
        return float(bytes) / dif

    @staticmethod
    def calc_eta(start, now, total, current):
        if total is None:
            return None
        if now is None:
            now = time.time()
        dif = now - start
        if current == 0 or dif < 0.001:  # One millisecond
            return None
        rate = float(current) / dif
        return int((float(total) - float(current)) / rate)

def run(filePath):
    lab = YJobsLab()
    storage = YStorage('')
    if filePath != None:
        jobMaintenance(addTask=True)
        job = createJob(filePath, storage)
        lab.addJob(job)
        if getProperty('runned'):
            DIALOG.notification(getString(30145), job.args['file'], xbmcgui.NOTIFICATION_INFO, 2000, False)
            exit()
    else:
        if getProperty('runned'):
            exit()

    setProperty('runned', True)
    pDialog = DialogCallback('Prepare upload')
    account_id = None
    youtube = None
    showSuccessNotify = False
    try:
        while (1):
            try:
                job = lab.peekJob()
                if not job:
                    log('not job')
                    break
                showSuccessNotify = True
                opt = job.opt
                args = job.args
                if account_id != opt['account_id']:
                    account_id = opt['account_id']
                    storage.switchAccount(account_id)
                    youtube = get_authenticated_service(storage)

                pDialog.start(os.path.basename(args['file']), job.opt['resumable_progress'])
                yid = initialize_upload(youtube, job, pDialog)
                playlist = args['yplaylist']
                if playlist:
                    playlists.add_video_to_playlist(youtube, yid, title=utils.to_utf8(playlist), privacy=args['privacyStatus'])
                stopIfNeed()
                lab.deleteJob()
                if job.opt['delete_file'] == 'true':
                    try:
                        os.remove(job.args['file'])
                    except OSError as e:
                        log.debug(e.__str__().decode('cp1251').encode('utf-8'))
                        DIALOG.ok("Error %s" % e.errno, e.strerror.decode('cp1251').encode('utf-8'), e.filename)
                xbmc.executebuiltin("Container.Refresh")
            except CurrentJobCancelException:
                lab.deleteJob()
                clearProperty('stop')
                showSuccessNotify = False
                continue
    except HttpError as e:
        log.error("An HTTP error %d occurred:\n%s" % (e.resp.status, e.content))
        raise
    except CancelledException:
        pass
    except Exception:
        raise
    else:
        if showSuccessNotify:
            DIALOG.notification(getString(30116), getString(30120), xbmcgui.NOTIFICATION_INFO, 2000, False)
    finally:
        pDialog.close()
        prop = getProperty('stop')

        if prop != 'deleteall':
            lab.saveJobProgress()
        clear()


def clear():
    clearProperty('runned')
    clearProperty('stop')


def createJob(filePath, storage):
    addon = ADDON
    basename = os.path.basename(filePath)
    addon.setSetting('title', basename)
    addon.setSetting('description', '')

    if (addon.getSetting('show_upload') == 'true'):
        settingsFile = os.path.join(DATA_DIR, 'settings.xml')
        try:
            stime = os.path.getmtime(settingsFile)
        except:
            stime = 0

        addon.openSettings()

        def isclose(f1, f2):
            return abs(f1 - f2) <= 0.0099999

        if isclose(os.path.getmtime(settingsFile), stime):
            log.debug('exited')
            exit()

    args = {}
    args['file'] = filePath
    args['title'] = addon.getSetting('title')
    args['description'] = addon.getSetting('description')
    args['keywords'] = addon.getSetting('keywords')
    args['category'] = getUploadCategrory()
    args['privacyStatus'] = getUploadPrivacy()
    args['yplaylist'] = addon.getSetting('yplaylist')
    options = {}


    def getAccountFromList(storage):
        list = storage.getNames()
        if not list:
            return None
        else:
            r = DIALOG.select(getString(30127), list)
            if r == -1:
                exit()
            return list[r]

    try:
        accountName = addon.getSetting('account')
        if not accountName:
            accountName = getAccountFromList(storage)

        accountId = None
        if accountName:
            try:
                accountId = storage.setName(accountName).getAccountId()
            except:
                utils.showInfoNotification(getString(30116), getString(30146))
                addon.setSetting('account', '')
                accountName = getAccountFromList(storage)
        if not accountName:
            accountName = createAccount()

        if not accountName:
            exit()
        else:
            options['account_id'] = accountId or storage.setName(accountName).getAccountId()()
            addon.setSetting('account', accountName)
            options['delete_file'] = addon.getSetting('delete_file_after_upload')
            options['resumable_uri'] = None
            options['resumable_progress'] = 0
    except CancelledException:
        exit()
    finally:
        addon.setSetting('title', '')
        addon.setSetting('description', '')

    job = Job(args, options)
    # log("created job:" + str(job))
    # exit()
    return job

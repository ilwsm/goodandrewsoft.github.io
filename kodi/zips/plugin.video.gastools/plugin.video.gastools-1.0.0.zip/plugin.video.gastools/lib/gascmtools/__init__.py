import xbmc
import xbmcvfs

import xbmcaddon, xbmc, xbmcgui

WINDOW = xbmcgui.Window(10000)
DIALOG = xbmcgui.Dialog()
MONITOR = xbmc.Monitor()


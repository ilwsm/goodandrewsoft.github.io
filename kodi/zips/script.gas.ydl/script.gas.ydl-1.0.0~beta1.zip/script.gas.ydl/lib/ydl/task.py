# coding=utf-8

# fix for datatetime.strptime returns None
from __future__ import unicode_literals

import datetime
import os
import sys
import threading
import time

from gasutils.utils import busyDialog

from .callback import MyCallback


class proxydt(datetime.datetime):

    @classmethod
    def strptime(cls, date_string, format):
        return datetime.datetime(*(time.strptime(date_string, format)[0:6]))


datetime.datetime = proxydt

# fix subprocess.Popen for hiding cmd in Windows
LOCK = threading.Lock()
POPEN = None

import subprocess


class ProxySubprocessPopen(subprocess.Popen):

    def __init__(self, *args, **kwargs):
        global POPEN
        with LOCK:
            POPEN = self
        super(ProxySubprocessPopen, self).__init__(*args, **kwargs)

    if (sys.platform == "win32"):
        # noinspection PyUnresolvedReferences
        def _execute_child(self, args, executable, preexec_fn, close_fds,
                           cwd, env, universal_newlines,
                           startupinfo, *kwargs):
            if startupinfo is None:
                startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags = 1
            startupinfo.wShowWindow = 0
            super(ProxySubprocessPopen, self)._execute_child(args, executable, preexec_fn, close_fds,
                                                             cwd, env, universal_newlines,
                                                             startupinfo, *kwargs)


subprocess.Popen = ProxySubprocessPopen

from gasutils import DIALOG, MONITOR

from . import ADDON, setProperty, clearProperty, getProperty, getString

from .exceptions import CanceledException

import xbmc, xbmcgui


def log(s):
    xbmc.log("[script.gas.ydl]%s" % str(s).decode('utf-8'), 2)


def getFormat(url):
    quality = ADDON.getSettingInt('video_quality')
    format = ''
    if quality == 0:
        format = 'bestvideo[height<?720]+bestaudio/best[height<?720]'
    elif quality == 1:
        format = 'bestvideo[height<=?720]+bestaudio/best[height<=?720]'
    elif quality == 2:
        format = 'bestvideo[height<=?1080]+bestaudio/best[height<=?1080]'
    elif quality == 3:
        format = 'bestvideo+bestaudio/best'
    elif quality == 4:
        from .callback import FormatExtractor
        from ydl.myydl import MyYoutubeDl
        def createFormatsForDialog(formats):
            from youtube_dl.utils import format_bytes
            def formatFileSize(fdict):
                res = ''
                if fdict.get('filesize') is not None:
                    res += format_bytes(fdict['filesize'])
                elif fdict.get('filesize_approx') is not None:
                    res += '~' + format_bytes(fdict['filesize_approx'])
                return res

            options = list()
            for f in formats:
                o = f.get('format_id') + ' - '
                if f.get('vcodec') == 'none':
                    o += f['ext']
                    o += ' ' + f.get('acodec')
                    av = ' (audio)'
                elif f.get('acodec') == 'none':
                    o += f['ext']
                    o += ' ' + MyYoutubeDl.format_resolution(f)
                    av = ' (video)'
                else:
                    o += f['ext']
                    o += ' ' + MyYoutubeDl.format_resolution(f)
                    av = ' (video+audio)'

                o += ' ' + formatFileSize(f)
                o += av
                options.append(o)

            return options

        fe = FormatExtractor()
        ydl_opts = {'listformats': True, 'logger': fe, 'no_color': True}

        with MyYoutubeDl(ydl_opts) as ydl:
            ydl.download([url])

        formats = fe.formats
        formats.reverse()
        options = createFormatsForDialog(formats)
        res = DIALOG.multiselect("Pick: video+audio OR video and audio OR video OR audio", options)
        if not res:
            raise CanceledException()
        sep = ''
        for r in res:
            format += sep
            format += formats[r]['format_id']
            sep = '+'
    return format + '[protocol^=http]'


def getOutputPath():
    path = ADDON.getSetting('last_download_path')
    if ADDON.getSettingBool('confirm_download_path') or not path:
        path = DIALOG.browse(0, 'Choose output path', 'files', '')
        if path:
            ADDON.setSetting('last_download_path', path)

    if not path:
        raise CanceledException()
    return path + r'%(title)s - %(resolution)s.%(ext)s'


def checkerThread():
    while 1:
        time.sleep(1)
        if MONITOR.abortRequested() or not getProperty('runned'):
            clearProperty('runned')
            with LOCK:
                if POPEN is not None and POPEN.poll() is None:
                    POPEN.terminate()
            break

def checkIfRunning():
    if not getProperty('runned'):
        return
    if xbmcgui.Dialog().yesno('Queue is not implemented yet', 'Do you want to stop the downloading?'):
        clearProperty('runned')
    exit()


def tryUpdate(callback):
    from ydl import updater
    updater.updateCore(callback)

@busyDialog
def run(filePath):
    checkIfRunning()
    setProperty('runned', True)
    th = threading.Thread(target=checkerThread)
    th.start()
    callback = MyCallback()
    try:
        try:
            from .myydl import MyYoutubeDl
        except ImportError as e:
            tryUpdate(callback)
            from .myydl import MyYoutubeDl

        yid = filePath.split('=')[-1]
        url = 'https://www.youtube.com/watch?v=' + yid

        ydl_opts = {
            'format': getFormat(url),
            'outtmpl': getOutputPath(),
            'progress_hooks': [callback.ydlhook],
            'logger': callback,
            'quiet': False,
            'no_color': True,
            'ffmpeg_location': ADDON.getSetting('ffmpeg')
        }

        log("%s - %s" % (url, ydl_opts))

        callback.start(getString(32035), getString(32036))

        from youtube_dl.utils import DownloadError
        try:
            with MyYoutubeDl(ydl_opts) as ydl:
                from ydl.myydl import MyPostProcessor
                ydl.add_post_processor(MyPostProcessor(callback))
                ydl.download([url])

            if not os.path.exists(callback.filepath):
                if not os.path.exists(ydl_opts['ffmpeg_location']):
                    raise DownloadError('%s not exist. The formats won\'t be merged.' % ydl_opts['ffmpeg_location'])
                else:
                    raise DownloadError('%s not exist' % callback.filepath)
        except DownloadError as e:
            DIALOG.ok(getString(32037), str(e))
            raise CanceledException
        clearProperty('runned')
    except Exception:
        callback.close()
        clearProperty('runned')
        try:
            raise
        except CanceledException:
            pass
    else:
        player = xbmc.Player()
        if not player.isPlayingVideo():
            if xbmcgui.Dialog().yesno(getString(32024), getString(32038) % os.path.basename(callback.filepath)):
                player.play(callback.filepath)
    finally:
        th.join()
        log('script exit !')

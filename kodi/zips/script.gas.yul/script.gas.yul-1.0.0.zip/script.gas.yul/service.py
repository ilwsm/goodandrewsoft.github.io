# -*- coding: utf-8 -*-
import os
import sys


from gascmtools.logger import log

# del sys.path[0:2]
# for p in sys.path: log(p)
# sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'lib'))
from lib import yul
from lib.yul import task


# sys.path.append(os.path.join(os.path.dirname(__file__), 'lib', 'yul'))
for p in sys.path: log(p)
# log('SECOND')
# for p in path:
#     log(p)
# import yul
# from yul import task
# from yul.ytools import getAccountDir


if __name__ == '__main__':
    if yul.ADDON.getSetting('resume_after_start') == 'true':
        task.run(None)



import xbmcaddon, xbmc
from gasutils import WINDOW
from gasutils.logger import Logger

ADDON_ID = 'script.gas.ydl'
ADDON = xbmcaddon.Addon(id=ADDON_ID)

try:
    DATA_DIR = xbmc.translatePath(ADDON.getAddonInfo('profile')).decode('utf-8')
except AttributeError:
    DATA_DIR = xbmc.translatePath(ADDON.getAddonInfo('profile'))


getString = ADDON.getLocalizedString
ADDON_ID = ADDON.getAddonInfo('id')

def setProperty(prop, var):
    WINDOW.setProperty("%s_%s" % (ADDON_ID, prop), str(var))

def getProperty(prop):
    return WINDOW.getProperty("%s_%s" % (ADDON_ID, prop))


def clearProperty(prop):
    return WINDOW.clearProperty("%s_%s" % (ADDON_ID, prop))

log = Logger(ADDON)
def foo(bar, result, index):
    print 'hello {0}'.format(bar)
    result[index] = "foo"

from threading import Thread


results = [None] * 1


thread = Thread(target=foo, args=('world!', results, 0))
thread.start()

# do some other stuff

print "\n"
print results  # what sound does a metasyntactic locomotive make?
# -*- coding: utf-8 -*-

class CancelledException(Exception):
    pass


class RecordExistsException(Exception):
    pass


class DontExistClientIDsException(Exception):
    pass


class CurrentJobCancelException(Exception):
    pass

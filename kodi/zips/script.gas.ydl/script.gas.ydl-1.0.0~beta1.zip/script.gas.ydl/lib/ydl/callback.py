from gasutils import utils
from gasutils.utils import closeBusyDialog, activateBusyDialog

from . import getProperty, log
from .exceptions import CanceledException

def stopIfNeed():
    if not getProperty('runned'):
        raise CanceledException


class FormatExtractor(object):

    def __init__(self):
        self.formats = None

    def debug(self, msg):
        self.formats = msg
        pass

    def warning(self, msg):
        pass

    def error(self, msg):
        pass


import xbmcgui


class MyCallback(object):

    def __init__(self, stopIfNeedFunc=stopIfNeed):
        super(MyCallback, self).__init__()
        self.stopIfNeedFunc = stopIfNeedFunc
        self.dialog = None
        self.percents = 0
        self.heading = None
        import re
        self.pattern = re.compile('(^\[[^]]*?\])\s(.*)')
        self.filepath = None

    def start(self, heading, line):
        closeBusyDialog()
        self.percents = 0
        self.heading = heading
        if not self.dialog:
            self.dialog = xbmcgui.DialogProgressBG()
            self.dialog.create(self.heading, line)
        else:
            self.dialog.update(self.percents, self.heading, line)

    def run(self, information):
        self.dialog.close()
        self.filepath = information['filepath']

    def debug(self, msg):
        if msg[0] == '\r':
            return
        sArr = self.pattern.findall(msg)
        if sArr:
            self.heading = sArr[0][0]
            msg = sArr[0][1]
        self.dialog.update(self.percents, self.heading, msg)

    def warning(self, msg):
        log('[warning]' + str(msg))
        # self.debug(msg)

    def error(self, msg):
        pass

    def update(self, heading, msg):
        self.heading = heading
        self.dialog.update(self.percents, self.heading, msg)

    def close(self):
        activateBusyDialog()
        if self.dialog:
            self.dialog.close()
            self.dialog = None

    def ydlhook(self, info):
        self.stopIfNeedFunc()
        self.heading = info['filename']
        if info['status'] == 'downloading':
            line = info['_speed_str']
            line += ' ETA: ' + info['_eta_str'] + '  |  '
            bytes = info['downloaded_bytes']
            totalBytes = info.get('total_bytes')
            if totalBytes is None:
                totalBytes = info.get('total_bytes_estimate')

            line += '(' + utils.simpleSize(bytes) + '/' + utils.simpleSize(totalBytes) + ')'
            self.percents = int(100 * bytes / totalBytes)
        else:
            line = info['status']

        self.dialog.update(self.percents, self.heading, line)

    def coreHook(self, numblocks, blocksize, filesize, url=None):
        self.stopIfNeedFunc()
        try:
            self.percents = min((numblocks * blocksize * 100) / filesize, 100)
        except:
            self.percents = 100
        self.dialog.update(self.percents, self.heading, url)

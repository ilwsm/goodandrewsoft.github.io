# coding=utf-8
import os
import sys
import threading
import time

import xbmc
import xbmcgui
from gascmtools import DIALOG
from gascmtools.logger import log
import yul

from yul import yjobs, task, ytools
from yul.exceptions import DialogCancelledException
from yul.playlists import get_playlists
from yul.uploader import get_authenticated_service
from yul.yclient import YStorage
from yul.yjobs import YJobsLab


def jobMaintenance():
    list = []
    runned = yul.getProperty('runned')
    jobs = YJobsLab.getJobsFiles()
    if runned:
        list.append("Stop uploading")
        list.append("Delete all upload tasks")
        list.append("Delete current upload task")
        r = DIALOG.select("Total upload tasks:%d" % len(jobs), list)
        if yul.getProperty('runned'):
            if r == 0:
                yul.setProperty('stop', 'stopall')
            elif r == 1:
                yjobs.YJobsLab.deleteAllJobs()
            elif r == 2:
                yul.setProperty('stop', 'deleteCurrent')

    else:
        if jobs:
            list.append("Delete all upload tasks")
            list.append("Resume uploading")
            r = DIALOG.select("Total upload tasks:%d" % len(jobs), list)
            if r == 0:
                yjobs.YJobsLab.deleteAllJobs()
            elif r == 1:
                task.run(None)


def getSettingsFile():
    return os.path.join(yul.DATA_DIR, 'settings.xml')


def setTemporary(prop, value):
    yul.ADDON.setSetting(prop, value)
    yul.setProperty(prop, value)


def changeDataInSettingsFile(id, data):
    import xml.etree.ElementTree
    settingsFile = getSettingsFile()
    time = os.path.getmtime(settingsFile)
    tempLog("time 1:%s" % time)
    et = xml.etree.ElementTree.parse(settingsFile)
    root = et.getroot()
    tag = root.find('setting[@id="%s"]' % id)
    tag.text = data
    et.write(settingsFile)
    os.utime(settingsFile, (time, time))
    tempLog("time 1:%s" % os.path.getmtime(settingsFile))


def renameAccount(accountName):
    newAccountName = DIALOG.input(yul.getString(30108), defaultt=accountName, type=xbmcgui.INPUT_ALPHANUM)
    if newAccountName:
        YStorage(accountName).rename(newAccountName)
        if yul.ADDON.getSetting('account') == accountName:
            changeDataInSettingsFile('account', newAccountName)
        if yul.getProperty('account') == accountName:
            setTemporary('account', newAccountName)


def removeAccount(accountName):
    YStorage(accountName).remove()
    if yul.ADDON.getSetting('account') == accountName:
        changeDataInSettingsFile('account', '')
    if yul.getProperty('account') == accountName:
        setTemporary('account', '')


def setAccount(accountName):
    setTemporary('account', accountName)


def createAccount():
    try:
        ytools.createAccount()
    except DialogCancelledException:
        pass


def tempLog(var):
    log(str(time.time()) + ": " + str(var))


def checkerThread():
    while (1):
        dialog_id = xbmcgui.getCurrentWindowDialogId()
        # tempLog("test did: %s" % dialog_id)
        if dialog_id not in (10140, 10146, 12000, 10103, 10160, 10101, 10107):
            yul.clearProperty("script_runned")
            yul.clearProperty("account")
            yul.clearProperty("yplaylist")
            tempLog("Thread exited. The dialog id %d is appear. All properties cleared" % dialog_id)
            exit()
        time.sleep(1)


def updateProperties():
    if not yul.getProperty('script_runned'):
        yul.setProperty('script_runned', True)
        threading.Thread(target=checkerThread).start()
        tempLog("Thread started!")
        yul.setProperty('account', yul.ADDON.getSetting('account'))
        yul.setProperty('yplaylist', yul.ADDON.getSetting('yplaylist'))
    else:
        tempLog("Thread NOT started!")


if __name__ == '__main__':

    if len(sys.argv) < 2:
        # jobMaintenance()
        DIALOG.notification(yul.getString(30116), yul.getString(30115), xbmcgui.NOTIFICATION_INFO, 2000, False)
        exit()

    arg = sys.argv[1]

    if arg.startswith('account'):
        updateProperties()
        if arg.endswith('add'):
            createAccount()
            exit()


        def doTask(text, func, repeat):
            while (1):
                list = YStorage.getAccountsNames()
                if not list:
                    if arg == 'account':
                        createAccount()
                        exit()
                    else:
                        DIALOG.notification(yul.getString(30116), yul.getString(30115), xbmcgui.NOTIFICATION_INFO, 2000, False)
                        exit()
                try:
                    index = list.index(yul.getProperty('account'))
                except:
                    index = -1
                tempLog("Index = %d" % index)
                r = DIALOG.select(text, list, preselect=index)
                if r == -1:
                    exit()
                func(list[r])
                if repeat and len(list) > repeat:
                    continue
                else:
                    break


        if arg.endswith('remove'):
            doTask("What account you want to remove?", removeAccount, 1)
        elif arg.endswith('rename'):
            doTask("What account you want to rename?", renameAccount, -1)
        else:
            doTask("Choose an account", setAccount, 0)

    elif arg == 'yplaylist':
        updateProperties()


        def addNewPlaylist():
            newPlaylist = DIALOG.input('', type=xbmcgui.INPUT_ALPHANUM, defaultt=yul.getProperty('yplaylist')).strip()
            setTemporary('yplaylist', newPlaylist)


        account = yul.getProperty('account')
        if not account:
            addNewPlaylist()
            exit()

        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
        playlists = get_playlists(get_authenticated_service(YStorage(account)))
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        if not playlists:
            addNewPlaylist()
            exit()

        try:
            index = playlists.index(yul.getProperty('yplaylist')) + 2
        except:
            index = -1

        playlists.insert(0, yul.getString(30122))
        playlists.insert(0, yul.getString(30107))

        r = DIALOG.select("chooser", playlists, preselect=index)
        if r == -1:
            exit()
        if r == 0:
            addNewPlaylist()
        elif r == 1:
            setTemporary('yplaylist', '')
        else:
            playlist = playlists[r]
            setTemporary('yplaylist', playlist)

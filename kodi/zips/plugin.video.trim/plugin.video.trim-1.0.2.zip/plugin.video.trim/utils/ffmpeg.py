# coding=utf-8

import subprocess, threading, time, os, re, locale

from utils import log, getOS

SW_HIDE = 0
STARTF_USESHOWWINDOW = 1

PROGRESS_PATTERN = re.compile(
    r'time\s*\=\s*(\S+)'
)

DURATION_PATTERN = re.compile(
    r'Duration:\s*([^,\n]*)'
)

OS = getOS()
ENCODING = locale.getpreferredencoding()

def toMS(timeStr):
    return sum([a * b for a, b in zip([3600, 60, 1], map(float, timeStr.split(':')))])


def parse_time(line):
    time = PROGRESS_PATTERN.findall(line)

    if not time:
        return None

    return toMS(time[0])


def parse_duration(line):
    time = DURATION_PATTERN.findall(line)

    if not time:
        return None

    return toMS(time[0])


def checkerThread(dialog, p, outFile, tr):
    t = threading.currentThread()

    canceled = None
    while (p.poll() == None):
        canceled = dialog.iscanceled()
        if (canceled):
            p.terminate()
        time.sleep(0.200)
        # time.sleep(1)

    if (canceled):
        try:
            os.remove(outFile)
        except Exception as e:
            log(str(e).decode('cp1251').encode('utf-8'))

    tr[0] = canceled
    log("Stopping as you wish:" + t.getName() + " dialog.iscanceled:" + str(canceled))


def start_ffmpeg(dialog, callback, ffmpegBinary, inputVideoFile, timecodes, outputVideoFile=None):

    length = len(timecodes)
    first_timecode = timecodes[0]
    videoDuration = None

    cmd = []
    cmd.append(ffmpegBinary.encode(ENCODING))
    cmd.append('-y')
    cmd.append('-hide_banner')
    cmd.append('-i')
    cmd.append(inputVideoFile.encode(ENCODING))

    if (length == 2):
        cmd.append('-ss')
        cmd.append(str(first_timecode))
        last_timecode = timecodes[length - 1]
        videoDuration = last_timecode - first_timecode
        cmd.append('-t')
        cmd.append(str(videoDuration))
        ofsep = '(%.2f-%.2f)' % (first_timecode, last_timecode)
    else:
        cmd.append('-ss')
        cmd.append(str(first_timecode))
        ofsep = '(%.2f-%s)' % (first_timecode, 'EOF')

    if (outputVideoFile == None):
        parts = os.path.splitext(inputVideoFile)
        outputVideoFile = parts[0] + ofsep + parts[1]

    # cmd = '%s -y -hide_banner -i %s%s%s -c copy \'%s\'' % (ffmpegBinary, inputVideoFile, begin, end, outputVideoFile)
    cmd.append('-c')
    cmd.append('copy')
    cmd.append(outputVideoFile.encode(ENCODING))

    log("starting %s" % (' '.join(cmd)))

    si = None
    if (OS == 'windows'):
        si = subprocess.STARTUPINFO()
        si.dwFlags = STARTF_USESHOWWINDOW
        si.wShowWindow = SW_HIDE
        if (cmd[0] == 'ffmpeg'):
            cmd[0] = 'ffmpeg.exe'

    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, startupinfo=si)

    tr = [None] * 1
    t = threading.Thread(target=checkerThread, args=(dialog, p, outputVideoFile, tr,))
    t.start()

    result = None

    if (videoDuration == None):
        for line in iter(p.stdout.readline, ""):
            if not line: break
            result = line
            duration = parse_duration(line)
            if (duration):
                videoDuration = duration - first_timecode
                break

    if (videoDuration == None):
        log("Cannot parse duration")
        p.wait()
    else:
        log("VideoDuration:" + str(videoDuration))
        for line in iter(p.stdout.readline, ""):
            if not line: break
            result = line
            time = parse_time(line)
            if (time):
                callback(dialog, videoDuration, time)

    t.join()
    exitCode = p.poll()
    log("The process poll is:" + str(exitCode) + ", tr[0]:" + str(tr[0]))

    if (tr[0]):
        raise NotImplementedError()

    if (exitCode != 0):
        raise OSError(result)

    return True

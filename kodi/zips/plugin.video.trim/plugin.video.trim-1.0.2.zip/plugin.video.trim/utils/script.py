import sys
import xbmcaddon


if len(sys.argv) > 1:
    addon = xbmcaddon.Addon()
    if (sys.argv[1] == "reset_ffmpeg"):
        addon.setSetting('ffmpeg', "ffmpeg.exe")
    elif (sys.argv[1] == "reset_opath"):
        addon.setSetting('opath', "[current]")

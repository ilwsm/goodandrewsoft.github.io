# coding=utf-8
import os
import sys
import threading
import time

import xbmc
import xbmcgui
from gasutils import DIALOG, utils
from lib.yul import ytools, getProperty, setProperty, DATA_DIR, ADDON, getString, clearProperty, log
from lib.yul.exceptions import CancelledException
from lib.yul.playlists import get_playlists
from lib.yul.uploader import get_authenticated_service
from lib.yul.yclient import YStorage
from lib.yul.client_ids import ClientIDsStorage



def getSettingsFile():
    return os.path.join(DATA_DIR, 'settings.xml')


def changeDataInSettingsFile(id, data):
    import xml.etree.ElementTree
    settingsFile = getSettingsFile()
    time = os.path.getmtime(settingsFile)
    tempLog("time 1:%s" % time)
    et = xml.etree.ElementTree.parse(settingsFile)
    root = et.getroot()
    tag = root.find('setting[@id="%s"]' % id)
    tag.text = data
    et.write(settingsFile)
    os.utime(settingsFile, (time, time))
    tempLog("time 1:%s" % os.path.getmtime(settingsFile))


def tempLog(var):
    log(str(time.time()) + ": " + str(var))


def checkerThread():
    while 1:
        dialog_id = xbmcgui.getCurrentWindowDialogId()
        # tempLog("test did: %s" % dialog_id)
        if dialog_id not in (10140, 10146, 12000, 10103, 10160, 10101, 10107):
            clearProperty("script_runned")
            clearProperty("account")
            clearProperty("yplaylist")
            tempLog("Thread exited. The dialog id %d is appear. All properties cleared" % dialog_id)
            exit()
        time.sleep(1)


def updateProperties():
    if not getProperty('script_runned'):
        setProperty('script_runned', True)
        threading.Thread(target=checkerThread).start()
        tempLog("Thread started!")
        setProperty('account', ADDON.getSetting('account'))
        setProperty('yplaylist', ADDON.getSetting('yplaylist'))
    else:
        tempLog("Thread NOT started!")


def setTemporary(prop, value):
    ADDON.setSetting(prop, value)
    setProperty(prop, value)


class SettingsLab(object):

    def __init__(self, storage):
        self.storage = storage
        arg = sys.argv[1]
        if '_' in arg:
            arr = arg.split('_')
            self.sid = arr[0]
            self.op = arr[1]
        else:
            self.sid = arg
            self.op = None  # mean choose.

        self.do()

    def doTask(self, text, func, repeat):
        while 1:
            list = self.storage.getNames()
            if not list and not self.doIfRecordNotExist():
                break
            try:
                index = list.index(getProperty(self.sid))
            except:
                index = -1

            r = DIALOG.select(text, list, preselect=index)
            if r == -1:
                break
            func(list[r])
            if repeat and len(list) > repeat:
                continue
            else:
                break

    def setTemporary(self, prop, value):
        setTemporary(prop, value)

    def rename(self, name):
        newName = DIALOG.input(self.getRenameInputString(), defaultt=name, type=xbmcgui.INPUT_ALPHANUM)
        if newName:
            self.storage.setName(name).rename(newName)
            if ADDON.getSetting(self.sid) == name:
                changeDataInSettingsFile(self.sid, newName)
            if getProperty(self.sid) == name:
                self.setTemporary(self.sid, newName)

    def remove(self, name):
        self.storage.setName(name).remove()
        if ADDON.getSetting(self.sid) == name:
            changeDataInSettingsFile(self.sid, '')
        if getProperty(self.sid) == name:
            self.setTemporary(self.sid, '')

    def set(self, name):
        self.setTemporary(self.sid, name)

    def create(self):
        raise NotImplementedError

    def doIfRecordNotExist(self):
        raise NotImplementedError

    def do(self):
        if self.op == 'remove':
            self.doTask(self.getRemoveString(), self.remove, 1)
        elif self.op == 'rename':
            self.doTask(self.getRenameString(), self.rename, -1)
        elif self.op == 'add':
            self.create()
        else:
            self.doTask(self.getChooseString(), self.set, 0)

    def getChooseString(self):
        return "Please choose"

    def getRemoveString(self):
        return "What exactly you want to remove?"

    def getRenameString(self):
        return "What exactly you want to rename?"

    def getRenameInputString(self):
        raise NotImplementedError


class SettingsLabAccounts(SettingsLab):

    def getRenameInputString(self):
        return getString(30108)

    def create(self):
        try:
            ytools.createAccount()
        except CancelledException:
            pass

    def doIfRecordNotExist(self):
        if not self.op:
            self.create()
        else:
            utils.showInfoNotification(getString(30116), getString(30115))
        return False

    def getChooseString(self):
        return getString(30127)


class SettingsLabClientIDs(SettingsLab):

    def doIfRecordNotExist(self):
        DIALOG.notification(getString(30116), getString(30128), xbmcgui.NOTIFICATION_INFO, 2000, False)
        return False

    def setTemporary(self, prop, value):
        pass

    def rename(self, name):
        newName = DIALOG.input(self.getRenameInputString(), defaultt=name, type=xbmcgui.INPUT_ALPHANUM)
        if newName:
            self.storage.setName(name).rename(newName)

    def remove(self, name):
        self.storage.setName(name).remove()

    def getRenameInputString(self):
        return "Please rename"

    def create(self):
        ytools.createClientIDs(self.storage)


if __name__ == '__main__':

    if len(sys.argv) < 2:
        ytools.jobMaintenance()
        exit()

    updateProperties()
    arg = sys.argv[1]

    if arg.startswith('account'):
        SettingsLabAccounts(YStorage(""))
    elif arg.startswith('client'):
        SettingsLabClientIDs(ClientIDsStorage(""))
    elif arg == 'yplaylist':

        def addNewPlaylist():
            newPlaylist = DIALOG.input('', type=xbmcgui.INPUT_ALPHANUM, defaultt=getProperty('yplaylist')).strip()
            setTemporary('yplaylist', newPlaylist)


        account = getProperty('account')
        if not account:
            utils.showInfoNotification(getString(30116), getString(30131))
            exit()

        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
        playlists = get_playlists(get_authenticated_service(YStorage(account)))
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        if not playlists:
            addNewPlaylist()
            exit()

        try:
            index = playlists.index(getProperty('yplaylist')) + 2
        except:
            index = -1

        playlists.insert(0, getString(30122))
        playlists.insert(0, getString(30107))

        r = DIALOG.select(getString(30124), playlists, preselect=index)
        if r == -1:
            exit()
        if r == 0:
            addNewPlaylist()
        elif r == 1:
            setTemporary('yplaylist', '')
        else:
            playlist = playlists[r]
            setTemporary('yplaylist', playlist)
    else:
        pass

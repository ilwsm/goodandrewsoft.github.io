import os

import xbmcgui
import xbmcvfs
from gasutils import utils, DIALOG

from . import DATA_DIR, ADDON, getString, log, getProperty, setProperty
from .exceptions import RecordExistsException, DontExistClientIDsException, CancelledException


def getOtherDataDir():
    dir = os.path.join(DATA_DIR, 'data')
    if not xbmcvfs.exists(dir):
        if not utils.make_dirs(dir):
            raise Exception('Failed to create directories in {filename}.'.format(filename=dir.encode("utf-8")))
    return dir


def get_api_keys():
    from .client_ids import ClientIDsStorage
    storage = ClientIDsStorage("")

    list = storage.getNames()
    if not list:
        raise DontExistClientIDsException()

    r = DIALOG.select_cbd(getString(30129), list)
    if r == -1:
        raise CancelledException()

    storage.setName(list[r])
    client_ids = storage.locked_get()

    client_id = client_ids['client_id']
    client_secret = client_ids['client_secret']
    if not client_id or not client_secret:
        raise DontExistClientIDsException()

    if not client_id.endswith(u'.apps.googleusercontent.com'):
        client_id += u'.apps.googleusercontent.com'

    log("client_id: %s" % client_id)
    log("client_secret: %s" % client_secret)
    return client_id, client_secret


def getUploadPrivacy():
    privacy = ADDON.getSetting('privacy')
    if privacy == '0':
        return 'public'
    elif privacy == '1':
        return 'private'
    else:
        return 'unlisted'


def getUploadCategrory():
    ids = [1, 2, 10, 15, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44]
    return str(ids[int(ADDON.getSetting('categories'))])


def handleClientIDsException(e):
    DIALOG.ok(getString(30142), getString(30143))


def createAccount():
    accountName = DIALOG.input(getString(30108), type=xbmcgui.INPUT_ALPHANUM)
    if accountName:
        from .yclient import YStorage
        storage = YStorage(accountName)
        try:
            storage.checkIfAccountExist()
        except RecordExistsException:
            DIALOG.notification(getString(30117), getString(30118), xbmcgui.NOTIFICATION_WARNING, 4000, True)
            return None
        import uploader
        try:
            uploader.createCredentails(storage)
        except DontExistClientIDsException as e:
            handleClientIDsException(e)
            return None

        utils.showInfoNotification(getString(30116), getString(30130))
    return accountName


def createClientIDs(ids_storage):
    name = DIALOG.input(getString(30139), type=xbmcgui.INPUT_ALPHANUM)
    if not name:
        return
    client_id = DIALOG.input(getString(30140), type=xbmcgui.INPUT_ALPHANUM)
    if not client_id:
        return
    client_secret = DIALOG.input(getString(30141), type=xbmcgui.INPUT_ALPHANUM)
    if not client_secret:
        return
    ids_storage.setName(name)
    client_ids = {'client_id': client_id, 'client_secret': client_secret}
    ids_storage.add(client_ids)
    utils.showInfoNotification(getString(30116), getString(30130))


def jobMaintenance(runned=getProperty('runned'), addTask=False):
    from . import task, yjobs
    from .yjobs import YJobsLab
    list = []

    jobs = YJobsLab.getJobsFiles()
    if runned:
        list.append(getString(30132))
        list.append(getString(30133))
        list.append(getString(30134))
        if addTask:
            list.append(getString(30137))
        r = DIALOG.select(getString(30125) % len(jobs), list)
        if getProperty('runned'):
            if r == 0:
                setProperty('stop', 'stopall')
            elif r == 1:
                yjobs.YJobsLab.deleteAllJobs()
            elif r == 2:
                setProperty('stop', 'deleteCurrent')
            elif r == 3:
                return
    elif jobs:
        list.append(getString(30133))
        if addTask:
            list.append(getString(30135))
        else:
            list.append(getString(30136))
        r = DIALOG.select(getString(30138) % len(jobs), list)
        if r == 0:
            yjobs.YJobsLab.deleteAllJobs()
        elif r == 1:
            if addTask:
                return
            task.run(None)
    else:
        if addTask:
            return
        DIALOG.ok(getString(30116), getString(30125) % 0)
    exit()

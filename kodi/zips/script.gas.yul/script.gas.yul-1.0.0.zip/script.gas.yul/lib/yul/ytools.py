import os
from base64 import b64decode

import xbmcvfs, xbmcgui
from gascmtools import utils, DIALOG

from . import DATA_DIR, key_sets, ADDON, getString
from .exceptions import AccountExistsException

def getAccountDir():
    accountsDir = os.path.join(DATA_DIR, 'accounts')
    if not xbmcvfs.exists(accountsDir):
        if not utils.make_dirs(accountsDir):
            raise Exception('Failed to create directories in {filename}.'.format(filename=accountsDir.encode("utf-8")))
    return accountsDir

def get_api_keys(switch):
    client_id = u''.join([b64decode(key_sets[switch]['id']).decode('utf-8'), u'.apps.googleusercontent.com'])
    client_secret = b64decode(key_sets[switch]['secret']).decode('utf-8')
    return client_id, client_secret

def getUploadPrivacy():
    privacy = ADDON.getSetting('privacy')
    if privacy == '0':
        return 'public'
    elif privacy == '1':
        return 'private'
    else:
        return 'unlisted'


def getUploadCategrory():
    ids = [1, 2, 10, 15, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44]
    return str(ids[int(ADDON.getSetting('categories'))])

def createAccount():
    accountName = DIALOG.input(getString(30108), type=xbmcgui.INPUT_ALPHANUM)
    if accountName:
        from .yclient import YStorage
        storage = YStorage(accountName)
        try:
            storage.checkIfAccountExist()
        except AccountExistsException:
            DIALOG.notification(getString(30117), getString(30118), xbmcgui.NOTIFICATION_WARNING, 4000, True)
            return None
        import uploader
        uploader.createCredentails(storage)
    return accountName

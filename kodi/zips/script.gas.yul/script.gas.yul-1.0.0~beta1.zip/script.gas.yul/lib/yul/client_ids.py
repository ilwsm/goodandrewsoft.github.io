import json
import os

from gasutils.utils import createFileIfNeeded

from .ytools import getOtherDataDir
from . import log
from .exceptions import RecordExistsException
from oauth2client import _helpers


class JsonStorage(object):

    def getJsonFile(self):
        raise NotImplementedError

    def __init__(self, name, fileName=None):
        self._filename = fileName or self.getJsonFile()
        self._data = None
        self._currentName = name

    def getNames(self):
        return self._getNames()

    def setName(self, accountName):
        self._currentName = accountName
        return self

    def getName(self):
        return self._currentName

    def getFilePath(self):
        return self._filename

    def _loadData(self):
        if self._data == None:
            self._forceLoadData()

    def _forceLoadData(self):
        createFileIfNeeded(self._filename)
        _helpers.validate_file(self._filename)
        try:
            f = open(self._filename, 'rb')
            content = f.read()
            f.close()
        except IOError:
            raise
        try:
            self._data = json.loads(_helpers._from_bytes(content))
        except ValueError as e:
            log.debug(e)
            self._data = dict()

    def _saveData(self):
        createFileIfNeeded(self._filename)
        _helpers.validate_file(self._filename)
        f = open(self._filename, 'w')
        f.write(json.dumps(self._data))
        f.close()

    def _getNames(self):
        self._loadData()
        data = self._data
        list = []
        for el in data:
            list.append(data[el]['name'])
        return list

    def _getCurrent(self):
        data = self._data
        for acc in data:
            if self._currentName == data[acc]['name']:
                return data[acc]
        return None

    def _getIndex(self):
        data = self._data
        for acc in data:
            if self._currentName == data[acc]['name']:
                return acc
        return None

    def locked_get(self):
        self._loadData()
        return self._getCurrent()

    def locked_put(self, object):
        self._loadData()
        index = self._getIndex()
        if index is None:
            index = str(len(self._data))
        data = self._data
        data[index] = self.getDictObject(object)
        data[index]['name'] = self._currentName
        self._saveData()

    def getDictObject(self, object):
        return object

    def checkIfExist(self):
        self._loadData()
        if self._getIndex() is not None:
            raise RecordExistsException()

    def locked_add(self, dictObject):
        self.checkIfExist()
        index = str(len(self._data))
        data = self._data

        data[index] = self.getDictObject(dictObject)
        data[index]['name'] = self._currentName
        self._saveData()

    def locked_rename(self, dst):
        self._loadData()
        current = self._getCurrent()
        current['name'] = dst
        self._saveData()

    def locked_remove(self, arg=None):
        self._loadData()
        index = self._getIndex()
        data = self._data
        del data[index]
        self._saveData()

    def put(self, dictObject):
        self._modifyData(self.locked_put, dictObject)

    def add(self, dictObject):
        self._modifyData(self.locked_add, dictObject)

    def rename(self, dst):
        self._modifyData(self.locked_rename, dst)

    def remove(self):
        self._modifyData(self.locked_remove, None)

    def _modifyData(self, func, arg):
        func(arg)


class ClientIDsStorage(JsonStorage):
    def __init__(self, name, fileName=None):
        super(ClientIDsStorage, self).__init__(name, fileName)

    def getJsonFile(self):
        return os.path.join(getOtherDataDir(), 'client_ids.json')

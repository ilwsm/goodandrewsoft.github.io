# coding=utf-8
import os
import sys

import YoutubeDLWrapper
import youtube_dl
from YDStreamExtractor import DownloadResult
from youtube_dl import DEFAULT_OUTTMPL

try:
    from gascmtools.logger import log
except:
    def log(text):
        print (text)


class MyLogger(object):
    def debug(self, msg):
        pass

    def warning(self, msg):
        pass

    def error(self, msg):
        log('Error while downloading: ' + msg)


def my_hook(d):
    if d['status'] == 'finished':
        log('Done downloading, now converting ...')


def testdl(path=None):
    format = 'bestvideo[height<=?1080]+bestaudio/best[height<=?1080]'

    ydl_opts = {
        'format': format,
        'logger': MyLogger(),
        'progress_hooks': [my_hook],
        'outtmpl': os.path.join("j:/", DEFAULT_OUTTMPL),
        # '-o' : enc_name+'.%(ext)s',
    }
    with youtube_dl.YoutubeDL(ydl_opts) as ydl:
        r = ydl.download(['https://www.youtube.com/watch?v=' + 'kAPL-XaGF8M'])
        log(r)
        return r


if __name__ == '__main__':
    testdl()

sys.path.append(r'F:\Run\Lprogr\JetBrains\PyCharm\helpers\pydev')


def other(filePath):
    __import__('pydevd').st()
    yid = filePath.split('=')[-1]
    url = 'https://www.youtube.com/watch?v=' + yid
    info = {'url': url}
    # info = YDStreamExtractor.getVideoInfo(url, 2)
    _handleDownload(info)

def _handleDownload(info, path=None, duration=None, bg=False):
    from YDStreamExtractor import setOutputCallback, _setDownloadDuration, util
    import YDStreamUtils as StreamUtils
    path = path or StreamUtils.getDownloadPath(use_default=True)
    if bg:
        downloader = StreamUtils.DownloadProgressBG
    else:
        downloader = StreamUtils.DownloadProgress

    with downloader(line1='Starting download...') as prog:

        try:
            setOutputCallback(prog.updateCallback)
            _setDownloadDuration(duration)
            result = download(info, util.TMP_PATH)
        finally:
            setOutputCallback(None)
            _setDownloadDuration(duration)

    if not result and result.status != 'canceled':
        StreamUtils.showMessage(StreamUtils.T(32013), result.message, bg=bg)
    elif result:
        StreamUtils.showMessage(StreamUtils.T(32011), StreamUtils.T(32012), '', result.filepath, bg=bg)
    filePath = result.filepath

    part = result.filepath + u'.part'
    try:
        if os.path.exists(part):
            os.rename(part, result.filepath)
    except UnicodeDecodeError:
        part = part.encode('utf-8')
        if os.path.exists(part):
            os.rename(part, result.filepath)

    if not StreamUtils.moveFile(filePath, path, filename=info.get('filename')):
        StreamUtils.showMessage(StreamUtils.T(32036), StreamUtils.T(32037), '', result.filepath, bg=bg)

    return result


def download(info, path, template='%(title)s-%(id)s.%(ext)s'):
    format = 'bestvideo[height<=?1080]+bestaudio/best[height<=?1080]'
    ytdl = YoutubeDLWrapper._getYTDL()
    ydl_opts = {
        'format': format,
        'logger': MyLogger(),
        # 'progress_hooks': [my_hook],
        'progress_hooks': [ytdl.progressCallback],
        'outtmpl': os.path.join("j:/", DEFAULT_OUTTMPL),
        'quiet': True
    }

    with youtube_dl.YoutubeDL(ydl_opts) as ydl:
        r = ydl.download([info['url']])

    return DownloadResult(True, filepath=ytdl._lastDownloadedFilePath)

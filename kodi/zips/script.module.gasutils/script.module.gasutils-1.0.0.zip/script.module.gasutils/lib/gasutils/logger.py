# -*- coding: utf-8 -*-

import xbmc

DEBUG = 0
INFO = 2
NOTICE = 2
WARNING = 3
ERROR = 4
SEVERE = 5
FATAL = 6
NONE = 7


class Logger(object):

    def __init__(self, addon):
        self.addonId = addon.getAddonInfo('id')

    def __call__(self, text, log_level=INFO):
        self.log(text, log_level=INFO)

    def log(self, text, log_level=INFO):
        log_line = '[%s]%s' % (self.addonId, text)
        xbmc.log(msg=log_line, level=log_level)

    def debug(self, text):
        self.log(text, DEBUG)

    def info(self, text):
        self.log(text, INFO)

    def notice(self, text):
        self.log(text, NOTICE)

    def warning(self, text):
        self.log(text, WARNING)

    def error(self, text):
        import traceback
        self.log('%s\n%s' % (text, traceback.format_exc()), ERROR)

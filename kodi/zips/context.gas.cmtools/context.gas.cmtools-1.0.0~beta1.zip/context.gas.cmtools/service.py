def brun():
    import xbmc, xbmcaddon, xbmcgui
    import os
    import shutil
    import sys
    import time
    import json

    from lib.RPCBuilder import RPCBuilder

    def log(s):
        xbmc.log("[context.gas.cmtools]" + str(s), 2)

    def addonIsEnabled(id):
        r = RPCBuilder(1, "Addons.GetAddonDetails").add("addonid", id).add("properties", ["enabled"]).execute()
        r = json.loads(r)
        log(r)
        if 'error' in r:
            if r['error']['code'] == -32602:
                return -1
        else:
            if r['result']['addon']['enabled'] == False:
                return 0
            else:
                return 1
        raise

    def setAddonEnabled(id, enabled):
        r = RPCBuilder(1, "Addons.SetAddonEnabled").add("addonid", id).add("enabled", enabled).execute()
        r = json.loads(r)
        if 'result' in r and r['result'] == 'OK':
            pass
        else:
            raise Exception("%s can't be %s" % (id, "enabled" if enabled is True else "disabled"))

    def installAddon(aid):
        for i in range(5):
            xbmc.executebuiltin('InstallAddon(%s)' % aid, False)
            time.sleep(1)
            did = xbmcgui.getCurrentWindowDialogId()
            # if addonIsEnabled(aid) < 0:
            if did not in [10100, 10101]:
                log("Addon %s can't install, step %d" % (aid, i))
                time.sleep(1)
                continue
            else:
                log("Addon %s probably installed" % (aid))
                return
        raise Exception("Addon %s can't install after all steps" % aid)

    def createRepo(raid):
        path = xbmcaddon.Addon().getAddonInfo('path')
        rpath = os.path.join(os.path.dirname(path), raid)
        path = os.path.join(path, 'resources', 'assets')

        try:
            os.makedirs(rpath)
        except OSError:
            shutil.rmtree(rpath)
            os.makedirs(rpath)

        shutil.copy(os.path.join(path, 'addon.xml'), os.path.join(rpath, 'addon.xml'))
        shutil.copy(os.path.join(path, 'icon.png'), os.path.join(rpath, 'icon.png'))

    def checkAddonCarefully(aid, func1=lambda: None, func2=lambda aid: exit(__import__('xbmcgui').Dialog().ok(aid, 'Is disabled'))):
        def checkIfExistInPath(aid):
            if not os.path.isdir(os.path.join(os.path.dirname(xbmcaddon.Addon().getAddonInfo('path')), aid)):
                raise Exception("%s - %s" % (sys.exc_info()[1], "Addon %s exist in kodi database, but him path dont'exist" % aid))

        r = addonIsEnabled(aid)
        if r == 1:
            checkIfExistInPath(aid)
            func1()
        elif r == 0:
            checkIfExistInPath(aid)
            func2(aid)

    def run():
        aid = 'script.module.gasutils'
        checkAddonCarefully(aid, exit)
        raid = 'repository.goodandrewsoft'
        checkAddonCarefully(raid, lambda: exit(installAddon(aid)))
        createRepo(raid)
        xbmc.executebuiltin('UpdateLocalAddons', True)
        setAddonEnabled(raid, True)
        installAddon(aid)

    run()

try:
    from gasutils.logger import Logger
except:
    brun()
